#include <windows.h>
#include <GL/glut.h>
#include <cmath>
#include <cstdlib>

int currentScene = 1;

namespace Sriti {

const float PI = 3.14159265f;


float birdX      = -50.0f;
float flagAngle  = 0.0f;
int   frameCount = 0;
float walkPhase  = 0.0f;

float gPanX = 0.0f, gPanY = 0.0f;
float gZoom = 1.0f;
float gRotateAngle = 0.0f;

bool isNight   = false;
bool isRaining = false;

const int RAIN_DROPS = 80;
float rainX[RAIN_DROPS];
float rainY[RAIN_DROPS];

const int PEOPLE_COUNT = 10;
float peopleX[PEOPLE_COUNT] = { 150, 450, 468, 250, 400, 320, 230, 360, -30, 630 };
float peopleSpeed[PEOPLE_COUNT] = { 1.1f, -1.3f, 1.2f, -0.9f, 1.4f, -1.1f, 1.0f, -1.2f, 1.4f, -1.4f };

void bezierPoint(float t, float x0, float y0, float x1, float y1, float x2, float y2,
                    float &outX, float &outY)
{
    float u = 1.0f - t;
    outX = u * u * x0 + 2.0f * u * t * x1 + t * t * x2;
    outY = u * u * y0 + 2.0f * u * t * y1 + t * t * y2;
}


const int BEZIER_STEPS = 48;
const int OUTLINE_PTS  = 2 * (BEZIER_STEPS + 1);

int buildShardOutline(float baseCenterX, float apexX, float baseY, float apexY, float halfWidth,
                        float outline[][2])
{
    float leftBaseX  = baseCenterX - halfWidth;
    float rightBaseX = baseCenterX + halfWidth;
    float ctrlX_L    = apexX - halfWidth * 0.15f;
    float ctrlX_R    = apexX + halfWidth * 0.15f;
    float ctrlY      = baseY + (apexY - baseY) * 0.22f;

    int n = 0;
    for (int i = 0; i <= BEZIER_STEPS; i++)
    {
        float t = (float)i / BEZIER_STEPS;
        bezierPoint(t, leftBaseX, baseY, ctrlX_L, ctrlY, apexX, apexY, outline[n][0], outline[n][1]);
        n++;
    }
    for (int i = 0; i <= BEZIER_STEPS; i++)
    {
        float t = (float)i / BEZIER_STEPS;
        bezierPoint(t, apexX, apexY, ctrlX_R, ctrlY, rightBaseX, baseY, outline[n][0], outline[n][1]);
        n++;
    }
    return n;
}

void drawShardFill(float outline[][2], int n, float r, float g, float b)
{
    glBegin(GL_POLYGON);
        glColor3f(r, g, b);
        for (int i = 0; i < n; i++)
            glVertex2f(outline[i][0], outline[i][1]);
    glEnd();
}


// Monument
void drawMonument()
{
    const int HALF_PAIRS = 6;
    const int SHARDS     = 2 * HALF_PAIRS + 1;

    float centerX     = 300.0f;
    float baseY       = 150.0f;
    float maxH        = 290.0f;
    float minH        = 65.0f;
    float baseSpacing = 31.0f;
    float halfWidth   = 19.0f;

    float baseCx[SHARDS], apexCx[SHARDS], apexYArr[SHARDS], shade[SHARDS];
    int count = 0;

    for (int ad = HALF_PAIRS; ad >= 0; ad--)
    {
        float h  = maxH - ad * ((maxH - minH) / (float)HALF_PAIRS);
        float sd = (ad % 2 == 0) ? 0.58f : 0.68f;

        if (ad == 0)
        {
            baseCx[count] = centerX;  apexCx[count] = centerX;
            apexYArr[count] = baseY + h;  shade[count] = sd;
            count++;
        }
        else
        {

            baseCx[count] = centerX - ad * baseSpacing;  apexCx[count] = centerX;
            apexYArr[count] = baseY + h;  shade[count] = sd;
            count++;

            baseCx[count] = centerX + ad * baseSpacing;  apexCx[count] = centerX;
            apexYArr[count] = baseY + h;  shade[count] = sd;
            count++;
        }
    }

    float outline[OUTLINE_PTS][2];


    for (int i = 0; i < count; i++)
    {
        int n = buildShardOutline(baseCx[i], apexCx[i], baseY, apexYArr[i], halfWidth, outline);
        drawShardFill(outline, n, shade[i], shade[i], shade[i]);
    }
}

// Sky
void drawSky()
{
    glBegin(GL_QUADS);
        if (isNight) glColor3f(0.06f, 0.08f, 0.20f);
        else         glColor3f(0.75f, 0.85f, 0.95f);
        glVertex2f(0, 150);
        glVertex2f(600, 150);
        glVertex2f(600, 600);
        glVertex2f(0, 600);
    glEnd();
}

//Sun
void drawSun()
{
    if (isNight) return;

    float cx = 520.0f, cy = 500.0f, r = 32.0f;

    // Rays
    glLineWidth(2.5f);
    glBegin(GL_LINES);
        glColor3f(1.0f, 0.75f, 0.25f);
        for (int a = 0; a < 360; a += 30)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(cx + (r + 6.0f) * cos(angle), cy + (r + 6.0f) * sin(angle));
            glVertex2f(cx + (r + 24.0f) * cos(angle), cy + (r + 24.0f) * sin(angle));
        }
    glEnd();

    // Sun disc
    glBegin(GL_POLYGON);
        glColor3f(1.0f, 0.82f, 0.30f);
        for (int a = 0; a <= 360; a += 20)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
        }
    glEnd();
}

// Moon and stars
void drawMoon()
{
    if (!isNight) return;

    float cx = 520.0f, cy = 500.0f, r = 26.0f;
    glBegin(GL_POLYGON);
        glColor3f(0.92f, 0.92f, 0.85f);
        for (int a = 0; a <= 360; a += 20)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
        }
    glEnd();

    // Crescent shadow
    glBegin(GL_POLYGON);
        if (isNight) glColor3f(0.06f, 0.08f, 0.20f);
        for (int a = 0; a <= 360; a += 20)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(cx + 10.0f + r * 0.85f * cos(angle), cy + r * 0.85f * sin(angle));
        }
    glEnd();
}

void drawStars()
{
    if (!isNight) return;

    glColor3f(1.0f, 1.0f, 0.95f);
    float starsX[] = { 40, 90, 150, 210, 270, 330, 560, 20, 480, 130, 350, 590 };
    float starsY[] = { 560, 520, 580, 540, 570, 510, 430, 400, 380, 460, 560, 350 };
    int n = sizeof(starsX) / sizeof(starsX[0]);

    glPointSize(2.5f);
    glBegin(GL_POINTS);
        for (int i = 0; i < n; i++)
            glVertex2f(starsX[i], starsY[i]);
    glEnd();
}

//Rain
void drawRain()
{
    if (!isRaining) return;

    glLineWidth(1.5f);
    glColor3f(0.7f, 0.8f, 0.95f);
    glBegin(GL_LINES);
        for (int i = 0; i < RAIN_DROPS; i++)
        {
            glVertex2f(rainX[i], rainY[i]);
            glVertex2f(rainX[i] - 4.0f, rainY[i] - 14.0f);
        }
    glEnd();
}


//  Ground
void drawGround()
{
    glBegin(GL_QUADS);
        glColor3f(0.55f, 0.27f, 0.19f);
        glVertex2f(0, 0);
        glVertex2f(600, 0);
        glVertex2f(600, 150);
        glVertex2f(0, 150);
    glEnd();
}

void drawWall(float xStart, float xEnd, float yTop)
{

    glBegin(GL_QUADS);
        glColor3f(0.40f, 0.18f, 0.12f);
        glVertex2f(xStart, 0);
        glVertex2f(xEnd, 0);
        glVertex2f(xEnd, yTop);
        glVertex2f(xStart, yTop);
    glEnd();


    glBegin(GL_QUADS);
        glColor3f(0.62f, 0.42f, 0.32f);
        glVertex2f(xStart, yTop - 3.0f);
        glVertex2f(xEnd, yTop - 3.0f);
        glVertex2f(xEnd, yTop);
        glVertex2f(xStart, yTop);
    glEnd();
}

void drawWalls()
{

    drawWall(10.0f, 95.0f, 24.0f);
    drawWall(505.0f, 590.0f, 24.0f);

    drawWall(84.0f, 100.0f, 45.0f);
    drawWall(75.0f, 108.0f, 10.0f);

    drawWall(500.0f, 516.0f, 45.0f);
    drawWall(492.0f, 525.0f, 10.0f);

    drawWall(178.0f, 194.0f, 45.0f);
    drawWall(170.0f, 202.0f, 10.0f);

    drawWall(406.0f, 422.0f, 45.0f);
    drawWall(398.0f, 430.0f, 10.0f);

    drawWall(0.0f, 22.0f, 100.0f);
    drawWall(0.0f, 22.0f, 30.0f);

    drawWall(578.0f, 600.0f, 100.0f);
    drawWall(578.0f, 600.0f, 30.0f);
}

void drawRect(float xLeft, float yBottom, float w, float h, float r, float g, float b)
{
    glBegin(GL_QUADS);
        glColor3f(r, g, b);
        glVertex2f(xLeft,     yBottom);
        glVertex2f(xLeft + w, yBottom);
        glVertex2f(xLeft + w, yBottom + h);
        glVertex2f(xLeft,     yBottom + h);
    glEnd();
}

// walking
void drawLimb(float length, float width, float r, float g, float b)
{
    glBegin(GL_QUADS);
        glColor3f(r, g, b);
        glVertex2f(-width * 0.5f, 0);
        glVertex2f(width * 0.5f, 0);
        glVertex2f(width * 0.5f, -length);
        glVertex2f(-width * 0.5f, -length);
    glEnd();
}

void drawPerson(float x, float y, float scale, float r, float g, float b, float phase)
{
    float hipY      = y + scale * 4.4f;
    float shoulderY = y + scale * 7.0f;
    float headY     = y + scale * 8.3f;

    float thigh = scale * 2.0f, shin = scale * 1.8f;
    float upperArm = scale * 1.8f, forearm = scale * 1.6f;

    float legSwing = sin(phase) * 24.0f;
    float lSwing =  legSwing, rSwing = -legSwing;
    float lKnee  = (lSwing < 0.0f) ? -lSwing * 0.5f : 0.0f;
    float rKnee  = (rSwing < 0.0f) ? -rSwing * 0.5f : 0.0f;
    float armSwing = -legSwing * 0.7f;

    // shadow
    glBegin(GL_POLYGON);
        glColor3f(0.35f, 0.32f, 0.29f);
        for (int a = 0; a <= 360; a += 30)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(x + scale * 1.1f * cos(angle), y + scale * 0.3f * sin(angle));
        }
    glEnd();

    // Left leg
    glPushMatrix();
        glTranslatef(x - scale * 0.55f, hipY, 0);
        glRotatef(lSwing, 0, 0, 1);
        drawLimb(thigh, scale * 0.75f, 0.16f, 0.16f, 0.21f);
        glTranslatef(0, -thigh, 0);
        glRotatef(lKnee, 0, 0, 1);
        drawLimb(shin, scale * 0.62f, 0.13f, 0.13f, 0.18f);
        glTranslatef(0, -shin, 0);
        glBegin(GL_QUADS);
            glColor3f(0.06f, 0.06f, 0.06f);
            glVertex2f(-scale * 0.5f, 0);      glVertex2f(scale * 0.65f, 0);
            glVertex2f(scale * 0.65f, -scale * 0.45f); glVertex2f(-scale * 0.5f, -scale * 0.45f);
        glEnd();
    glPopMatrix();

    //Right leg
    glPushMatrix();
        glTranslatef(x + scale * 0.55f, hipY, 0);
        glRotatef(rSwing, 0, 0, 1);
        drawLimb(thigh, scale * 0.75f, 0.16f, 0.16f, 0.21f);
        glTranslatef(0, -thigh, 0);
        glRotatef(rKnee, 0, 0, 1);
        drawLimb(shin, scale * 0.62f, 0.13f, 0.13f, 0.18f);
        glTranslatef(0, -shin, 0);
        glBegin(GL_QUADS);
            glColor3f(0.06f, 0.06f, 0.06f);
            glVertex2f(-scale * 0.5f, 0);      glVertex2f(scale * 0.65f, 0);
            glVertex2f(scale * 0.65f, -scale * 0.45f); glVertex2f(-scale * 0.5f, -scale * 0.45f);
        glEnd();
    glPopMatrix();

    // Torso
    glBegin(GL_QUADS);
        glColor3f(r, g, b);
        glVertex2f(x - scale * 1.05f, hipY);
        glVertex2f(x + scale * 1.05f, hipY);
        glVertex2f(x + scale * 0.95f, shoulderY);
        glVertex2f(x - scale * 0.95f, shoulderY);
    glEnd();

    // Left arm
    glPushMatrix();
        glTranslatef(x - scale * 0.95f, shoulderY, 0);
        glRotatef(-armSwing, 0, 0, 1);
        drawLimb(upperArm, scale * 0.55f, r * 0.9f, g * 0.9f, b * 0.9f);
        glTranslatef(0, -upperArm, 0);
        drawLimb(forearm, scale * 0.45f, 0.92f, 0.78f, 0.62f);
    glPopMatrix();

    // Right arm
    glPushMatrix();
        glTranslatef(x + scale * 0.95f, shoulderY, 0);
        glRotatef(armSwing, 0, 0, 1);
        drawLimb(upperArm, scale * 0.55f, r * 0.9f, g * 0.9f, b * 0.9f);
        glTranslatef(0, -upperArm, 0);
        drawLimb(forearm, scale * 0.45f, 0.92f, 0.78f, 0.62f);
    glPopMatrix();

    // Head
    glBegin(GL_POLYGON);
        glColor3f(0.92f, 0.78f, 0.62f);
        for (int a = 0; a <= 360; a += 30)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(x + scale * 0.85f * cos(angle), headY + scale * 0.85f * sin(angle));
        }
    glEnd();
}

void drawPeople()
{
    float laneY[PEOPLE_COUNT]    = { 50, 45, 42, 62, 100, 55, 45, 95, 55, 70 };
    float laneScale[PEOPLE_COUNT] = { 5.0f, 5.0f, 4.5f, 4.0f, 4.0f, 4.2f, 4.0f, 3.8f, 4.5f, 4.5f };
    float laneR[PEOPLE_COUNT] = { 0.15f, 0.35f, 0.15f, 0.2f, 0.15f, 0.2f, 0.15f, 0.25f, 0.15f, 0.2f };
    float laneG[PEOPLE_COUNT] = { 0.15f, 0.1f,  0.15f, 0.2f, 0.15f, 0.15f,0.15f, 0.15f, 0.15f, 0.1f };
    float laneB[PEOPLE_COUNT] = { 0.15f, 0.1f,  0.15f, 0.2f, 0.15f, 0.15f,0.2f,  0.1f,  0.15f, 0.1f };

    for (int i = 0; i < PEOPLE_COUNT; i++)
    {
        float phase = walkPhase * (peopleSpeed[i] > 0 ? 1.0f : -1.0f) + i * 0.7f;
        drawPerson(peopleX[i], laneY[i], laneScale[i], laneR[i], laneG[i], laneB[i], phase);
    }
}

//  pool
void drawPool()
{
    float cx = 300.0f, cy = 90.0f;
    float rx = 110.0f, ry = 16.0f;


    glBegin(GL_POLYGON);
        glColor3f(0.55f, 0.75f, 0.85f);
        for (int i = 0; i <= 360; i += 10)
        {
            float angle = i * PI / 180.0f;
            glVertex2f(cx + rx * cos(angle), cy + ry * sin(angle));
        }
    glEnd();


    glLineWidth(2.0f);
    glBegin(GL_LINE_LOOP);
        glColor3f(0.25f, 0.35f, 0.4f);
        for (int i = 0; i < 360; i += 10)
        {
            float angle = i * PI / 180.0f;
            glVertex2f(cx + rx * cos(angle), cy + ry * sin(angle));
        }
    glEnd();
}

// Flag
void drawFlag()
{
    float poleX = 290.0f;


    glLineWidth(4.0f);
    glBegin(GL_LINES);
        glColor3f(0.2f, 0.2f, 0.2f);
        glVertex2f(poleX, 30);
        glVertex2f(poleX, 200);
    glEnd();


    glBegin(GL_TRIANGLES);
        glColor3f(0.2f, 0.2f, 0.2f);
        glVertex2f(poleX - 11, 30);
        glVertex2f(poleX + 11, 30);
        glVertex2f(poleX, 44);
    glEnd();

    glPushMatrix();
        glTranslated(poleX, 180, 0);
        glRotated(flagAngle, 0, 0, 1);


        glBegin(GL_QUADS);
            glColor3f(0.0f, 0.4f, 0.2f);
            glVertex2f(0, 0);
            glVertex2f(42, 0);
            glVertex2f(42, -21);
            glVertex2f(0, -21);
        glEnd();


        glBegin(GL_POLYGON);
            glColor3f(0.8f, 0.0f, 0.0f);
            for (int i = 0; i <= 360; i += 20)
            {
                float angle = i * PI / 180.0f;
                float x = 17 + 7 * cos(angle);
                float y = -10 + 7 * sin(angle);
                glVertex2f(x, y);
            }
        glEnd();
    glPopMatrix();
}

//small bird
void drawBird(float x, float y)
{
    glPushMatrix();
        glTranslated(x, y, 0);
        glLineWidth(2.0f);
        glBegin(GL_LINE_STRIP);
            glColor3f(0.1f, 0.1f, 0.1f);
            glVertex2f(-8, 0);
            glVertex2f(-3, 4);
            glVertex2f(0, 0);
            glVertex2f(3, 4);
            glVertex2f(8, 0);
        glEnd();
    glPopMatrix();
}

void drawBirds()
{
    drawBird(birdX, 480);
    drawBird(birdX - 120, 520);
}

// Simple tree
void drawTree(float cx, float cy, float r)
{
    glBegin(GL_QUADS);
        glColor3f(0.4f, 0.25f, 0.1f);
        glVertex2f(cx - 3, cy - 20);
        glVertex2f(cx + 3, cy - 20);
        glVertex2f(cx + 3, cy);
        glVertex2f(cx - 3, cy);
    glEnd();

    glBegin(GL_POLYGON);
        glColor3f(0.13f, 0.45f, 0.15f);
        for (int i = 0; i <= 360; i += 20)
        {
            float angle = i * PI / 180.0f;
            glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
        }
    glEnd();
}

void drawTrees()
{
    drawTree(60, 170, 25);
    drawTree(110, 165, 20);
    drawTree(500, 165, 20);
    drawTree(550, 170, 25);
}

// tree
void drawFoliageClump(float cx, float cy, float r, float shadeMul)
{
    glBegin(GL_POLYGON);
        glColor3f(0.10f * shadeMul, 0.42f * shadeMul, 0.14f * shadeMul);
        for (int a = 0; a <= 360; a += 24)
        {
            float angle = a * PI / 180.0f;
            glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
        }
    glEnd();
}

void drawRealisticTree(float baseX, float baseY, float scale)
{

    glBegin(GL_QUADS);
        glColor3f(0.32f, 0.20f, 0.10f);
        glVertex2f(baseX - 3.0f * scale, baseY);
        glVertex2f(baseX + 3.0f * scale, baseY);
        glVertex2f(baseX + 1.6f * scale, baseY + 16.0f * scale);
        glVertex2f(baseX - 1.6f * scale, baseY + 16.0f * scale);
    glEnd();

    float topY = baseY + 15.0f * scale;

    drawFoliageClump(baseX - 6.0f * scale, topY + 2.0f * scale, 9.0f * scale, 0.85f);
    drawFoliageClump(baseX + 6.0f * scale, topY + 1.0f * scale, 8.5f * scale, 1.05f);
    drawFoliageClump(baseX,               topY + 9.0f * scale, 10.0f * scale, 1.0f);
    drawFoliageClump(baseX - 3.0f * scale, topY + 13.0f * scale, 7.0f * scale, 1.15f);
    drawFoliageClump(baseX + 4.0f * scale, topY + 12.0f * scale, 7.5f * scale, 0.95f);
}

void drawBigTrees()
{

    drawRealisticTree(75.0f,  150.0f, 2.7f);
    drawRealisticTree(150.0f, 150.0f, 3.3f);
    drawRealisticTree(450.0f, 150.0f, 3.3f);
    drawRealisticTree(525.0f, 150.0f, 2.7f);
    drawRealisticTree(50.0f,  150.0f, 2.3f);
}

// jungle
void drawJungleBackdrop()
{
    float positions[] = { 0, 40, 80, 120, 160, 200, 240, 280, 320, 360, 400, 440, 480, 520, 560, 600 };
    int   count = sizeof(positions) / sizeof(positions[0]);

    for (int i = 0; i < count; i++)
    {
        float cx = positions[i];
        float cy = 195.0f + (i % 2) * 5.0f;
        float r  = 20.0f + (i % 3) * 3.0f;
        float m  = 0.55f + (i % 3) * 0.08f;

        glBegin(GL_POLYGON);
            glColor3f(0.12f * m, 0.30f * m, 0.15f * m);
            for (int a = 0; a <= 360; a += 30)
            {
                float angle = a * PI / 180.0f;
                glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
            }
        glEnd();
    }
}

// Dense
void drawBackgroundTrees()
{
    float positions[] = { 20, 70, 120, 170, 220, 270, 330, 380, 430, 480, 530, 580 };
    int   count = sizeof(positions) / sizeof(positions[0]);

    for (int i = 0; i < count; i++)
    {
        float cx = positions[i];
        float cy = 180.0f + (i % 3) * 4.0f;
        float r  = 18.0f + (i % 3) * 3.0f;
        float shade = (i % 2 == 0) ? 0.16f : 0.20f;

        glBegin(GL_POLYGON);
            glColor3f(shade * 0.5f, shade + 0.16f, shade * 0.6f);
            for (int a = 0; a <= 360; a += 30)
            {
                float angle = a * PI / 180.0f;
                glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
            }
        glEnd();
    }
}


void applyProjection();
void drawNightOverlay();

void display()
{
    applyProjection();
    glClear(GL_COLOR_BUFFER_BIT);

    drawSky();
    drawSun();
    drawMoon();
    drawStars();
    drawTrees();
    drawGround();
    drawWalls();
    drawJungleBackdrop();
    drawBackgroundTrees();
    drawBigTrees();
    drawMonument();
    drawPool();
    drawFlag();
    drawPeople();
    drawBirds();
    drawNightOverlay();
    drawRain();

    glFlush();
}


void timer(int value)
{
    frameCount++;

    birdX += 3.0f;
    if (birdX > 650.0f) {
        birdX = -50.0f;
    }

    flagAngle = 12.0f * sin(frameCount * 0.1f);

    walkPhase += 0.35f;

    for (int i = 0; i < PEOPLE_COUNT; i++)
    {
        peopleX[i] += peopleSpeed[i];
        if (peopleX[i] > 630.0f) peopleX[i] = -30.0f;
        if (peopleX[i] < -30.0f) peopleX[i] = 630.0f;
    }

    if (isRaining)
    {
        for (int i = 0; i < RAIN_DROPS; i++)
        {
            rainY[i] -= 14.0f;
            if (rainY[i] < 0.0f)
            {
                rainY[i] = 600.0f;
                rainX[i] = (float)(rand() % 600);
            }
        }
    }

    glutPostRedisplay();
    glutTimerFunc(30, timer, 0);
}


void applyProjection()
{
    float hw = 300.0f / gZoom;
    float hh = 300.0f / gZoom;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(300.0f - hw + gPanX, 300.0f + hw + gPanX,
               300.0f - hh + gPanY, 300.0f + hh + gPanY);
    glRotatef(gRotateAngle, 0.0f, 0.0f, 1.0f);
    glMatrixMode(GL_MODELVIEW);
}

void init()
{
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 600, 0, 600);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    for (int i = 0; i < RAIN_DROPS; i++)
    {
        rainX[i] = (float)(rand() % 600);
        rainY[i] = (float)(rand() % 600);
    }
}


void drawNightOverlay()
{
    if (!isNight) return;

    glBegin(GL_QUADS);
        glColor4f(0.04f, 0.05f, 0.15f, 0.45f);
        glVertex2f(0, 0);
        glVertex2f(600, 0);
        glVertex2f(600, 600);
        glVertex2f(0, 600);
    glEnd();
}

void reshape(int w, int h)
{
    int side = (w < h) ? w : h;
    glViewport((w - side) / 2, (h - side) / 2, side, side);
    applyProjection();
}
//Keyboard
void keyboard(unsigned char key, int x, int y)
{
    if (key == 'd' || key == 'D') { isNight = false; }
    else if (key == 'n' || key == 'N') { isNight = true; }
    else if (key == 'r' || key == 'R') { isRaining = !isRaining; }
    else if (key == '+' || key == '=') { gZoom *= 1.1f; }
    else if (key == '-' || key == '_') { gZoom /= 1.1f; if (gZoom < 0.1f) gZoom = 0.1f; }
    else if (key == 'v' || key == 'V')
    {
        gPanX = 0.0f; gPanY = 0.0f; gZoom = 1.0f; gRotateAngle = 0.0f;
    }
    glutPostRedisplay();
}

void specialKeys(int key, int x, int y)
{
    float step = 12.0f;
    if (key == GLUT_KEY_LEFT)  gPanX -= step;
    if (key == GLUT_KEY_RIGHT) gPanX += step;
    if (key == GLUT_KEY_UP)    gPanY += step;
    if (key == GLUT_KEY_DOWN)  gPanY -= step;
    glutPostRedisplay();
}

}


namespace Shaheed {

float timeValue = 0.0f;
bool isPaused = false;
float speedFactor = 1.0f;

struct Person {
    float x;
    float y;
    float speed;
    int direction;
    float r, g, b;
    bool hasFlower;
    bool isOffering;
    float offerTimer;
};

Person people[4] = {
    {-0.9f, -0.45f, 0.003f,  1, 0.8f, 0.2f, 0.1f, true,  false, 0.0f},
    { 0.9f, -0.47f, 0.0025f, -1, 0.1f, 0.3f, 0.7f, true,  false, 0.0f},
    {-0.7f, -0.49f, 0.0035f,  1, 0.2f, 0.6f, 0.3f, true,  false, 0.0f},
    { 0.7f, -0.43f, 0.002f,  -1, 0.9f, 0.5f, 0.1f, true,  false, 0.0f}
};

struct PlacedFlower {
    float x, y;
    bool active;
};
PlacedFlower altarFlowers[10];
int flowerCount = 0;

void drawRect(float x1, float y1, float x2, float y2);
void drawCircle(float cx, float cy, float r);

void keyboard(unsigned char key, int x, int y) {
    if (key == 'p' || key == 'P') {
        isPaused = !isPaused;
    }
    else if (key == 'f' || key == 'F') {
        speedFactor += 0.5f;
        if (speedFactor > 3.0f) speedFactor = 3.0f;
    }
    else if (key == 's' || key == 'S') {
        speedFactor -= 0.3f;
        if (speedFactor < 0.2f) speedFactor = 0.2f;
    }
    else if (key == 27) {
        exit(0);
    }
    glutPostRedisplay();
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        timeValue += 0.5f;
        glutPostRedisplay();
    }
}

void drawRect(float x1, float y1, float x2, float y2) {
    glBegin(GL_QUADS);
        glVertex2f(x1, y1); glVertex2f(x2, y1);
        glVertex2f(x2, y2); glVertex2f(x1, y2);
    glEnd();
}

void drawCircle(float cx, float cy, float r) {
    glBegin(GL_POLYGON);
    for (int i = 0; i < 100; i++) {
        float angle = 2.0f * 3.14159f * i / 100;
        glVertex2f(cx + r * cos(angle), cy + r * sin(angle));
    }
    glEnd();
}

void drawCloud(float x, float y) {
    glColor3f(0.92f, 0.95f, 1.0f);
    drawCircle(x, y, 0.05f);
    drawCircle(x + 0.04f, y + 0.015f, 0.065f);
    drawCircle(x + 0.09f, y, 0.05f);
    drawRect(x - 0.01f, y - 0.02f, x + 0.10f, y + 0.01f);
}

void drawTree(float x, float y, float scale) {
    glColor3f(0.22f, 0.13f, 0.04f);
    drawRect(x - 0.02f * scale, y, x + 0.02f * scale, y + 0.35f * scale);

    glColor3f(0.04f, 0.40f, 0.10f);
    drawCircle(x, y + 0.45f * scale, 0.16f * scale);
    glColor3f(0.06f, 0.48f, 0.14f);
    drawCircle(x - 0.11f * scale, y + 0.35f * scale, 0.13f * scale);
    drawCircle(x + 0.11f * scale, y + 0.35f * scale, 0.13f * scale);
}

void drawWavingFlag() {
    glColor3f(0.4f, 0.4f, 0.42f);
    drawRect(0.68f, -0.38f, 0.695f, 0.65f);
    glColor3f(0.8f, 0.8f, 0.2f);
    drawCircle(0.6875f, 0.655f, 0.012f);

    glColor3f(0.0f, 0.52f, 0.22f);
    glBegin(GL_QUAD_STRIP);
    for (int i = 0; i <= 25; i++) {
        float px = 0.695f + (i * 0.009f);
        float wave = sin(timeValue * 5.0f + i * 0.25f) * 0.014f;
        glVertex2f(px, 0.62f + wave);
        glVertex2f(px, 0.45f + wave);
    }
    glEnd();

    float midWave = sin(timeValue * 5.0f + 12 * 0.25f) * 0.014f;
    glColor3f(0.92f, 0.05f, 0.05f);
    drawCircle(0.795f, 0.535f + midWave, 0.048f);
}

void drawShaheedMinar() {
    for (int i = 0; i < 5; i++) {
        float shade = 0.70f + (i * 0.03f);
        glColor3f(shade, shade, shade + 0.02f);
        drawRect(-0.70f + (i * 0.03f), -0.38f - (i * 0.03f), 0.70f - (i * 0.03f), -0.35f - (i * 0.03f));
    }

    glColor3f(0.90f, 0.02f, 0.02f);
    drawCircle(0.0f, 0.12f, 0.23f);

    glColor3f(0.94f, 0.94f, 0.94f);
    drawRect(-0.16f, -0.35f, -0.11f, 0.38f);
    drawRect(0.11f, -0.35f, 0.16f, 0.38f);
    drawRect(-0.02f, -0.35f, 0.02f, 0.38f);

    glColor3f(0.4f, 0.4f, 0.4f);
    drawRect(-0.065f, -0.35f, -0.055f, 0.38f);
    drawRect(0.055f, -0.35f, 0.065f, 0.38f);

    glColor3f(0.98f, 0.98f, 0.98f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.17f, 0.38f); glVertex2f(0.17f, 0.38f);
        glVertex2f(0.20f, 0.49f);  glVertex2f(-0.20f, 0.49f);
    glEnd();

    glColor3f(0.90f, 0.90f, 0.90f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.32f, -0.35f); glVertex2f(-0.22f, -0.35f);
        glVertex2f(-0.24f, 0.22f);  glVertex2f(-0.34f, 0.22f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(0.22f, -0.35f); glVertex2f(0.32f, -0.35f);
        glVertex2f(0.34f, 0.22f);  glVertex2f(0.24f, 0.22f);
    glEnd();

    glColor3f(0.96f, 0.96f, 0.96f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.34f, 0.22f); glVertex2f(-0.24f, 0.22f);
        glVertex2f(-0.21f, 0.26f); glVertex2f(-0.31f, 0.26f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(0.24f, 0.22f); glVertex2f(0.34f, 0.22f);
        glVertex2f(0.31f, 0.26f); glVertex2f(0.21f, 0.26f);
    glEnd();

    glColor3f(0.86f, 0.86f, 0.86f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.46f, -0.35f); glVertex2f(-0.37f, -0.35f);
        glVertex2f(-0.39f, 0.08f);  glVertex2f(-0.48f, 0.08f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(0.37f, -0.35f); glVertex2f(0.46f, -0.35f);
        glVertex2f(0.48f, 0.08f);  glVertex2f(0.39f, 0.08f);
    glEnd();

    glColor3f(0.94f, 0.94f, 0.94f);
    glBegin(GL_POLYGON);
        glVertex2f(-0.48f, 0.08f); glVertex2f(-0.39f, 0.08f);
        glVertex2f(-0.37f, 0.11f); glVertex2f(-0.46f, 0.11f);
    glEnd();
    glBegin(GL_POLYGON);
        glVertex2f(0.39f, 0.08f); glVertex2f(0.48f, 0.08f);
        glVertex2f(0.46f, 0.11f); glVertex2f(0.37f, 0.11f);
    glEnd();

    glColor3f(0.1f, 0.5f, 0.1f);
    drawCircle(0.0f, -0.35f, 0.055f);
    glColor3f(0.95f, 0.05f, 0.05f);
    drawCircle(0.0f, -0.35f, 0.035f);
    glColor3f(1.0f, 0.85f, 0.0f);
    for (int i = 0; i < 8; i++) {
        float ang = i * (2.0f * 3.14159f / 8.0f);
        drawCircle(0.045f * cos(ang), -0.35f + 0.045f * sin(ang), 0.012f);
    }

    for (int i = 0; i < flowerCount; i++) {
        if (altarFlowers[i].active) {
            glColor3f(0.95f, 0.1f, 0.1f);
            drawCircle(altarFlowers[i].x, altarFlowers[i].y, 0.02f);
            glColor3f(1.0f, 0.8f, 0.0f);
            drawCircle(altarFlowers[i].x, altarFlowers[i].y, 0.01f);
        }
    }
}

void drawTeaStallArea() {
    float baseX = -0.75f;
    float baseY = -0.45f;

    glColor3f(0.35f, 0.20f, 0.10f);
    drawRect(baseX - 0.08f, baseY, baseX + 0.08f, baseY + 0.02f);
    drawRect(baseX - 0.07f, baseY - 0.08f, baseX - 0.05f, baseY);
    drawRect(baseX + 0.05f, baseY - 0.08f, baseX + 0.07f, baseY);

    glColor3f(0.88f, 0.65f, 0.45f);
    drawCircle(baseX - 0.05f, baseY + 0.09f, 0.018f);
    glColor3f(0.1f, 0.4f, 0.8f);
    drawRect(baseX - 0.065f, baseY + 0.02f, baseX - 0.035f, baseY + 0.07f);
    glColor3f(1.0f, 1.0f, 1.0f);
    drawRect(baseX - 0.03f, baseY + 0.03f, baseX - 0.015f, baseY + 0.045f);

    glColor3f(0.88f, 0.65f, 0.45f);
    drawCircle(baseX + 0.05f, baseY + 0.09f, 0.018f);
    glColor3f(0.1f, 0.6f, 0.3f);
    drawRect(baseX + 0.035f, baseY + 0.02f, baseX + 0.065f, baseY + 0.07f);
    glColor3f(1.0f, 1.0f, 1.0f);
    drawRect(baseX + 0.015f, baseY + 0.03f, baseX + 0.03f, baseY + 0.045f);

    glColor3f(0.9f, 0.9f, 0.9f);
    glLineWidth(1.2f);
    float steamY = sin(timeValue * 6.0f) * 0.005f;
    glBegin(GL_LINES);
        glVertex2f(baseX - 0.022f, baseY + 0.048f); glVertex2f(baseX - 0.020f, baseY + 0.065f + steamY);
        glVertex2f(baseX + 0.022f, baseY + 0.048f); glVertex2f(baseX + 0.024f, baseY + 0.065f + steamY);
    glEnd();
}

void drawPerson(Person p) {
    float x = p.x;
    float y = p.y;
    int dir = p.direction;

    glColor3f(0.88f, 0.65f, 0.45f);
    drawCircle(x, y + 0.11f, 0.018f);

    float bend = p.isOffering ? -0.015f : 0.0f;
    glColor3f(p.r, p.g, p.b);
    drawRect(x - 0.012f, y + 0.02f + bend, x + 0.012f, y + 0.09f + bend);

    float swing = p.isOffering ? 0.0f : sin(timeValue * 10.0f + x * 20.0f) * 0.018f;
    glColor3f(0.15f, 0.15f, 0.2f);
    glLineWidth(3.0f);
    glBegin(GL_LINES);
        glVertex2f(x - 0.005f, y + 0.02f + bend); glVertex2f(x - 0.008f + swing, y - 0.04f);
        glVertex2f(x + 0.005f, y + 0.02f + bend); glVertex2f(x + 0.008f - swing, y - 0.04f);
    glEnd();

    glColor3f(p.r * 0.8f, p.g * 0.8f, p.b * 0.8f);
    glLineWidth(2.5f);

    if (p.isOffering) {
        glBegin(GL_LINES);
            glVertex2f(x, y + 0.08f + bend);
            glVertex2f(x + (0.03f * dir), y + 0.01f);
        glEnd();

        glColor3f(0.95f, 0.1f, 0.1f);
        drawCircle(x + (0.035f * dir), y + 0.01f, 0.015f);
    }
    else {
        glBegin(GL_LINES);
            glVertex2f(x, y + 0.08f);
            glVertex2f(x - (0.015f * dir) - swing, y + 0.03f);
        glEnd();

        if (p.hasFlower) {
            float handX = x + (0.018f * dir) + swing;
            float handY = y + 0.04f;

            glLineWidth(2.5f);
            glBegin(GL_LINES);
                glVertex2f(x, y + 0.08f);
                glVertex2f(handX, handY);
            glEnd();

            glColor3f(0.95f, 0.1f, 0.1f);
            drawCircle(handX + (0.005f * dir), handY + 0.015f, 0.012f);
            glColor3f(1.0f, 0.8f, 0.1f);
            drawCircle(handX + (0.012f * dir), handY + 0.01f, 0.01f);
        }
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    float skyCycle = (sin(timeValue * 0.4f) + 1.0f) / 2.0f;
    glClearColor(0.05f + 0.45f * skyCycle, 0.1f + 0.55f * skyCycle, 0.25f + 0.65f * skyCycle, 1.0f);

    if (skyCycle > 0.3f) {
        glColor3f(1.0f, 0.85f, 0.2f);
        drawCircle(-0.7f + (1.4f * skyCycle), 0.72f, 0.075f);
    } else {
        glColor3f(0.95f, 0.95f, 0.82f);
        drawCircle(0.65f, 0.75f, 0.055f);
    }

    float cloudX1 = -0.9f + fmod(timeValue * 0.05f, 2.0f);
    float cloudX2 = -0.4f + fmod(timeValue * 0.03f, 2.0f);
    drawCloud(cloudX1, 0.68f);
    drawCloud(cloudX2, 0.75f);

    drawTree(-0.85f, -0.38f, 1.3f);
    drawTree(-0.62f, -0.38f, 1.1f);
    drawTree(0.58f, -0.38f, 1.15f);
    drawTree(0.82f, -0.38f, 1.35f);

    glColor3f(0.35f, 0.35f, 0.38f);
    drawRect(-1.0f, -1.0f, 1.0f, -0.38f);

    drawShaheedMinar();
    drawWavingFlag();
    drawTeaStallArea();

    for (int i = 0; i < 4; i++) {
        drawPerson(people[i]);
    }

    glutSwapBuffers();
}

void update(int value) {
    if (!isPaused) {
        timeValue += 0.02f * speedFactor;

        for (int i = 0; i < 4; i++) {
            if (people[i].hasFlower && abs(people[i].x) < 0.22f && !people[i].isOffering) {
                people[i].isOffering = true;
                people[i].offerTimer = 0.0f;
            }

            if (people[i].isOffering) {
                people[i].offerTimer += 0.05f * speedFactor;
                if (people[i].offerTimer > 2.0f) {
                    people[i].isOffering = false;
                    people[i].hasFlower = false;

                    if (flowerCount < 10) {
                        altarFlowers[flowerCount].x = people[i].x + (0.03f * people[i].direction);
                        altarFlowers[flowerCount].y = -0.36f;
                        altarFlowers[flowerCount].active = true;
                        flowerCount++;
                    }
                }
            }
            else {
                people[i].x += (people[i].speed * speedFactor) * people[i].direction;

                if (people[i].x > 0.95f) {
                    people[i].direction = -1;
                    people[i].hasFlower = true;
                } else if (people[i].x < -0.95f) {
                    people[i].direction = 1;
                    people[i].hasFlower = true;
                }
            }
        }
    }
    glutPostRedisplay();
    glutTimerFunc(30, update, 0);
}

void init() {
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

} // namespace Shaheed

#pragma push_macro("PI")
#undef PI

namespace Sangsad {

#define PI 3.14159265358979323846

float flagWave = 0.0f;
float birdMove = 0.0f;
float birdWing = 0.0f;

float carMove = 0.0f;
float wheelAngle = 0.0f;

bool carMoving = true;
bool carVisible = true;

void circle(float cx, float cy, float r, int segments = 100)
{
    glBegin(GL_POLYGON);

    for (int i = 0; i < segments; i++)
    {
        float angle = 2.0f * PI * i / segments;

        glVertex2f(
            cx + cos(angle) * r * 0.5625f,
            cy + sin(angle) * r
        );
    }

    glEnd();
}

void ellipse(float cx, float cy, float rx, float ry, int segments = 100)
{
    glBegin(GL_POLYGON);

    for (int i = 0; i < segments; i++)
    {
        float angle = 2.0f * PI * i / segments;

        glVertex2f(
            cx + cos(angle) * rx,
            cy + sin(angle) * ry
        );
    }

    glEnd();
}

void rect(float x1, float y1, float x2, float y2)
{
    glBegin(GL_QUADS);

    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);

    glEnd();
}

void drawSky()
{
    int parts = 100;

    for (int i = 0; i < parts; i++)
    {
        float t1 = (float)i / parts;
        float t2 = (float)(i + 1) / parts;

        float y1 = -0.166667f + i * (1.166667f / parts);
        float y2 = -0.166667f + (i + 1) * (1.166667f / parts);

        float r1 = 0.68f - 0.18f * t1;
        float g1 = 0.86f - 0.08f * t1;
        float b1 = 0.97f;

        float r2 = 0.68f - 0.18f * t2;
        float g2 = 0.86f - 0.08f * t2;
        float b2 = 0.97f;

        glBegin(GL_QUADS);

        glColor3f(r1, g1, b1);
        glVertex2f(-1.0f, y1);
        glVertex2f(1.0f, y1);

        glColor3f(r2, g2, b2);
        glVertex2f(1.0f, y2);
        glVertex2f(-1.0f, y2);

        glEnd();
    }
}

void drawSun()
{
    glColor4f(1.0f, 0.88f, 0.32f, 0.07f);
    circle(0.734375f, 0.805556f, 0.172222f);

    glColor4f(1.0f, 0.88f, 0.32f, 0.12f);
    circle(0.734375f, 0.805556f, 0.127778f);

    glColor3f(1.0f, 0.83f, 0.25f);
    circle(0.734375f, 0.805556f, 0.086111f);
}

void drawCloud(float x, float y, float scale)
{
    glPushMatrix();

    glTranslatef(x, y, 0.0f);
    glScalef(scale, scale, 1.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.88f);

    circle(-0.085938f, 0.000000f, 0.058333f);
    circle(-0.054688f, 0.005556f, 0.069444f);
    circle(-0.018750f, 0.008333f, 0.072222f);
    circle(0.018750f, 0.008333f, 0.072222f);
    circle(0.056250f, 0.005556f, 0.066667f);
    circle(0.087500f, 0.000000f, 0.055556f);

    circle(-0.043750f, 0.050000f, 0.069444f);
    circle(0.000000f, 0.069444f, 0.088889f);
    circle(0.046875f, 0.047222f, 0.072222f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.35f);

    circle(-0.015625f, 0.077778f, 0.050000f);
    circle(0.023438f, 0.063889f, 0.044444f);

    glPopMatrix();
}

void drawClouds()
{
    drawCloud(-0.742188f, 0.708333f, 0.74f);
    drawCloud(-0.257812f, 0.861111f, 0.53f);
    drawCloud(0.468750f, 0.744444f, 0.61f);
}

void drawBird(float x, float y, float scale, float phase)
{
    float wing = sin(birdWing + phase) * 0.019444f * scale;

    glColor3f(0.06f, 0.07f, 0.08f);
    glLineWidth(2.2f);

    glBegin(GL_LINE_STRIP);

    glVertex2f(
        x - 0.023438f * scale,
        y + wing
    );

    glVertex2f(x, y);

    glVertex2f(
        x + 0.023438f * scale,
        y + wing
    );

    glEnd();

    glLineWidth(1.0f);
}

void drawBirds()
{
    float bob = sin(birdWing * 0.45f) * 0.008333f;

    drawBird(
        -0.562500f + birdMove,
        0.694444f + bob,
        0.72f,
        0.0f
    );

    drawBird(
        -0.492188f + birdMove,
        0.763889f + bob,
        0.56f,
        0.8f
    );

    drawBird(
        -0.414062f + birdMove,
        0.680556f + bob,
        0.50f,
        1.5f
    );
}

void drawDistantGreenery()
{
    glColor3f(0.07f, 0.28f, 0.08f);
    rect(-1.0f, -0.202778f, 1.0f, -0.125000f);

    for (float x = -1.0f; x <= 1.0f; x += 0.059375f)
    {
        circle(x, -0.125000f, 0.075000f);
    }

    glColor3f(0.11f, 0.38f, 0.11f);

    for (float x = -0.968750f; x <= 1.0f; x += 0.093750f)
    {
        circle(x, -0.119444f, 0.050000f);
    }
}

void drawLake()
{
    int parts = 40;

    for (int i = 0; i < parts; i++)
    {
        float y1 = -0.583333f + i * (0.402778f / parts);
        float y2 = -0.583333f + (i + 1) * (0.402778f / parts);

        float t = (float)i / parts;

        glColor3f(
            0.12f + 0.08f * t,
            0.57f + 0.13f * t,
            0.78f + 0.10f * t
        );

        rect(-1.0f, y1, 1.0f, y2);
    }

    glColor4f(1.0f, 1.0f, 1.0f, 0.20f);

    glBegin(GL_LINES);

    for (int i = 0; i < 18; i++)
    {
        float y = -0.561111f + i * 0.020000f;
        float x1 = -0.953125f + (i % 4) * 0.054688f;
        float x2 = 0.937500f - (i % 5) * 0.046875f;

        glVertex2f(x1, y);
        glVertex2f(x2, y);
    }

    glEnd();

    glColor4f(0.25f, 0.80f, 0.93f, 0.34f);

    glBegin(GL_LINES);

    for (int i = 0; i < 10; i++)
    {
        float y = -0.527778f + i * 0.030556f;

        glVertex2f(
            -0.843750f + i * 0.023438f,
            y
        );

        glVertex2f(
            -0.453125f + i * 0.012500f,
            y
        );

        glVertex2f(
            0.187500f - i * 0.007812f,
            y
        );

        glVertex2f(
            0.750000f - i * 0.020313f,
            y
        );
    }

    glEnd();

    glColor3f(0.70f, 0.55f, 0.41f);
    rect(-1.0f, -0.186111f, 1.0f, -0.166667f);

    glColor3f(0.83f, 0.76f, 0.65f);
    rect(-1.0f, -0.166667f, 1.0f, -0.152778f);
}

void drawRearCentralBuilding()
{
    glColor3f(0.56f, 0.55f, 0.52f);

    rect(-0.343750f, -0.125000f, -0.218750f, 0.416667f);
    rect(0.218750f, -0.125000f, 0.343750f, 0.416667f);

    glColor3f(0.64f, 0.63f, 0.59f);

    rect(-0.273438f, -0.125000f, 0.273438f, 0.527778f);

    glColor3f(0.69f, 0.68f, 0.64f);

    rect(-0.210938f, 0.500000f, 0.210938f, 0.597222f);

    glColor3f(0.73f, 0.72f, 0.68f);

    rect(-0.140625f, 0.583333f, 0.140625f, 0.644444f);

    glColor3f(0.77f, 0.76f, 0.71f);

    rect(-0.085938f, 0.633333f, 0.085938f, 0.669444f);

    glColor4f(0.25f, 0.24f, 0.22f, 0.25f);

    glBegin(GL_LINES);

    for (float y = -0.069444f; y <= 0.486111f; y += 0.055556f)
    {
        glVertex2f(-0.268750f, y);
        glVertex2f(0.268750f, y);
    }

    for (float x = -0.218750f; x <= 0.218750f; x += 0.062500f)
    {
        glVertex2f(x, -0.111111f);
        glVertex2f(x, 0.500000f);
    }

    glEnd();
}

void drawLeftWing()
{
    glColor3f(0.70f, 0.69f, 0.65f);

    rect(-0.812500f, -0.152778f, -0.273438f, 0.277778f);

    glColor3f(0.73f, 0.72f, 0.68f);

    rect(-0.757812f, -0.152778f, -0.328125f, 0.347222f);

    glColor3f(0.66f, 0.65f, 0.61f);

    rect(-0.343750f, -0.152778f, -0.203125f, 0.430556f);

    glColor3f(0.60f, 0.59f, 0.56f);

    rect(-0.843750f, -0.152778f, -0.773438f, 0.236111f);

    glColor3f(0.76f, 0.75f, 0.71f);

    rect(-0.773438f, 0.263889f, -0.328125f, 0.347222f);

    glColor4f(0.30f, 0.29f, 0.27f, 0.22f);

    glBegin(GL_LINES);

    for (float y = -0.097222f; y <= 0.305556f; y += 0.055556f)
    {
        glVertex2f(-0.757812f, y);
        glVertex2f(-0.328125f, y);
    }

    for (float x = -0.710938f; x <= -0.359375f; x += 0.070312f)
    {
        glVertex2f(x, -0.147222f);
        glVertex2f(x, 0.338889f);
    }

    glEnd();

    glColor4f(1.0f, 1.0f, 0.95f, 0.13f);

    rect(-0.753125f, -0.138889f, -0.743750f, 0.327778f);
}

void drawRightWing()
{
    glColor3f(0.70f, 0.69f, 0.65f);

    rect(0.273438f, -0.152778f, 0.812500f, 0.277778f);

    glColor3f(0.73f, 0.72f, 0.68f);

    rect(0.328125f, -0.152778f, 0.757812f, 0.347222f);

    glColor3f(0.66f, 0.65f, 0.61f);

    rect(0.203125f, -0.152778f, 0.343750f, 0.430556f);

    glColor3f(0.60f, 0.59f, 0.56f);

    rect(0.773438f, -0.152778f, 0.843750f, 0.236111f);

    glColor3f(0.76f, 0.75f, 0.71f);

    rect(0.328125f, 0.263889f, 0.773438f, 0.347222f);

    glColor4f(0.30f, 0.29f, 0.27f, 0.22f);

    glBegin(GL_LINES);

    for (float y = -0.097222f; y <= 0.305556f; y += 0.055556f)
    {
        glVertex2f(0.328125f, y);
        glVertex2f(0.757812f, y);
    }

    for (float x = 0.359375f; x <= 0.710938f; x += 0.070312f)
    {
        glVertex2f(x, -0.147222f);
        glVertex2f(x, 0.338889f);
    }

    glEnd();

    glColor4f(1.0f, 1.0f, 0.95f, 0.13f);

    rect(0.743750f, -0.138889f, 0.753125f, 0.327778f);
}

void drawCentralFacade()
{
    glColor3f(0.76f, 0.75f, 0.70f);

    rect(-0.218750f, -0.152778f, 0.218750f, 0.541667f);

    glColor3f(0.68f, 0.67f, 0.63f);

    rect(-0.257812f, -0.152778f, -0.187500f, 0.486111f);
    rect(0.187500f, -0.152778f, 0.257812f, 0.486111f);

    glColor4f(0.27f, 0.26f, 0.23f, 0.24f);

    glBegin(GL_LINES);

    for (float y = -0.097222f; y <= 0.486111f; y += 0.058333f)
    {
        glVertex2f(-0.210938f, y);
        glVertex2f(0.210938f, y);
    }

    for (float x = -0.164062f; x <= 0.164062f; x += 0.065625f)
    {
        glVertex2f(x, -0.138889f);
        glVertex2f(x, 0.522222f);
    }

    glEnd();

    glColor3f(0.075f, 0.095f, 0.11f);

    rect(-0.075000f, -0.125000f, 0.075000f, 0.444444f);

    glColor3f(0.035f, 0.050f, 0.060f);

    rect(-0.042188f, -0.125000f, 0.042188f, 0.172222f);

    glColor4f(0.70f, 0.73f, 0.70f, 0.28f);

    for (float y = -0.061111f; y <= 0.138889f; y += 0.061111f)
    {
        rect(-0.035937f, y, 0.035937f, y + 0.005556f);
    }

    glColor4f(1.0f, 1.0f, 0.95f, 0.14f);

    rect(-0.215625f, -0.138889f, -0.207812f, 0.522222f);
    rect(0.207812f, -0.138889f, 0.215625f, 0.522222f);
}

void drawTriangleOpening(float cx, float bottom, float width, float height)
{
    glColor3f(0.07f, 0.095f, 0.115f);

    glBegin(GL_TRIANGLES);

    glVertex2f(cx, bottom + height);
    glVertex2f(cx - width / 2.0f, bottom);
    glVertex2f(cx + width / 2.0f, bottom);

    glEnd();

    glColor4f(0.0f, 0.0f, 0.0f, 0.16f);

    glBegin(GL_TRIANGLES);

    glVertex2f(cx, bottom + height - 0.038889f);
    glVertex2f(cx - width / 2.0f + 0.010937f, bottom + 0.016667f);
    glVertex2f(cx + width / 2.0f - 0.010937f, bottom + 0.016667f);

    glEnd();
}

void drawRoundOpening(float cx, float cy, float radius)
{
    float radiusX = radius * 0.5625f;

    glColor3f(0.07f, 0.095f, 0.11f);

    circle(cx, cy, radius);

    glColor3f(0.50f, 0.51f, 0.49f);

    rect(
        cx - 0.004687f,
        cy - radius + 0.008333f,
        cx + 0.004687f,
        cy + radius - 0.008333f
    );

    for (
        float x = cx - radiusX + 0.017188f;
        x <= cx + radiusX - 0.017188f;
        x += 0.020313f
    )
    {
        rect(
            x,
            cy - radius + 0.013889f,
            x + 0.002656f,
            cy + radius - 0.013889f
        );
    }

    glColor4f(1.0f, 1.0f, 1.0f, 0.09f);

    ellipse(
        cx - radiusX * 0.25f,
        cy + radius * 0.15f,
        radiusX * 0.25f,
        radius * 0.55f
    );
}

void drawFacadeOpenings()
{
    drawTriangleOpening(-0.656250f, -0.055556f, 0.075000f, 0.300000f);
    drawRoundOpening(-0.507812f, 0.019444f, 0.094444f);
    drawTriangleOpening(-0.367188f, -0.013889f, 0.070312f, 0.291667f);

    drawTriangleOpening(0.367188f, -0.013889f, 0.070312f, 0.291667f);
    drawRoundOpening(0.507812f, 0.019444f, 0.094444f);
    drawTriangleOpening(0.656250f, -0.055556f, 0.075000f, 0.300000f);

    glColor3f(0.075f, 0.095f, 0.11f);

    rect(-0.445312f, -0.125000f, -0.418750f, 0.283333f);
    rect(0.418750f, -0.125000f, 0.445312f, 0.283333f);

    glColor4f(0.80f, 0.82f, 0.80f, 0.18f);

    rect(-0.440625f, -0.111111f, -0.434375f, 0.263889f);
    rect(0.423437f, -0.111111f, 0.429688f, 0.263889f);
}

void drawSideConcreteDetails()
{
    glColor3f(0.61f, 0.60f, 0.57f);

    rect(-0.843750f, -0.152778f, -0.820312f, 0.222222f);
    rect(0.820312f, -0.152778f, 0.843750f, 0.222222f);

    glColor3f(0.79f, 0.78f, 0.73f);

    rect(-0.812500f, 0.222222f, -0.773438f, 0.277778f);
    rect(0.773438f, 0.222222f, 0.812500f, 0.277778f);

    glColor4f(0.18f, 0.18f, 0.16f, 0.20f);

    glBegin(GL_LINES);

    glVertex2f(-0.820312f, -0.111111f);
    glVertex2f(-0.820312f, 0.222222f);

    glVertex2f(0.820312f, -0.111111f);
    glVertex2f(0.820312f, 0.222222f);

    glEnd();
}

void drawTopDetails()
{
    glColor3f(0.79f, 0.78f, 0.74f);

    rect(-0.226562f, 0.500000f, 0.226562f, 0.541667f);

    glColor3f(0.72f, 0.71f, 0.67f);

    rect(-0.164062f, 0.583333f, 0.164062f, 0.616667f);

    glColor3f(0.82f, 0.81f, 0.77f);

    rect(-0.101562f, 0.633333f, 0.101562f, 0.666667f);

    glColor4f(0.30f, 0.29f, 0.26f, 0.20f);

    rect(-0.226562f, 0.500000f, 0.226562f, 0.511111f);
    rect(-0.164062f, 0.583333f, 0.164062f, 0.594444f);
}

void drawParliamentPlaza()
{
    glColor3f(0.69f, 0.60f, 0.49f);

    rect(-0.898438f, -0.205556f, 0.898438f, -0.147222f);

    glColor3f(0.76f, 0.69f, 0.59f);

    rect(-0.812500f, -0.233333f, 0.812500f, -0.194444f);

    glColor3f(0.82f, 0.77f, 0.68f);

    rect(-0.656250f, -0.261111f, 0.656250f, -0.225000f);

    glColor3f(0.88f, 0.84f, 0.75f);

    rect(-0.523438f, -0.286111f, 0.523438f, -0.250000f);

    glColor3f(0.90f, 0.87f, 0.79f);

    rect(-0.421875f, -0.308333f, 0.421875f, -0.277778f);

    for (int i = 0; i < 9; i++)
    {
        float y = -0.313889f - i * 0.013889f;
        float width = 0.406250f + i * 0.037500f;
        float shade = 0.92f - i * 0.012f;

        glColor3f(
            shade,
            shade - 0.025f,
            shade - 0.09f
        );

        rect(
            -width / 2.0f,
            y,
            width / 2.0f,
            y + 0.014444f
        );
    }

    glColor3f(0.70f, 0.65f, 0.57f);

    rect(-0.440625f, -0.313889f, -0.418750f, -0.205556f);
    rect(0.418750f, -0.313889f, 0.440625f, -0.205556f);

    glColor4f(0.28f, 0.23f, 0.17f, 0.18f);

    rect(-0.898438f, -0.205556f, 0.898438f, -0.191667f);
    rect(-0.656250f, -0.261111f, 0.656250f, -0.250000f);

    glColor4f(1.0f, 1.0f, 0.94f, 0.25f);

    glBegin(GL_LINES);

    glVertex2f(-0.343750f, -0.286111f);
    glVertex2f(-0.343750f, -0.233333f);

    glVertex2f(-0.218750f, -0.286111f);
    glVertex2f(-0.218750f, -0.233333f);

    glVertex2f(0.218750f, -0.286111f);
    glVertex2f(0.218750f, -0.233333f);

    glVertex2f(0.343750f, -0.286111f);
    glVertex2f(0.343750f, -0.233333f);

    glEnd();
}

void drawFlag()
{
    float wave = sin(flagWave) * 0.011111f;

    glColor3f(0.61f, 0.61f, 0.58f);

    rect(-0.014062f, -0.250000f, 0.014063f, -0.227778f);

    glColor3f(0.82f, 0.83f, 0.80f);

    rect(-0.003906f, -0.236111f, 0.002344f, 0.244444f);

    glColor3f(0.64f, 0.65f, 0.63f);

    circle(-0.000781f, 0.247222f, 0.011111f);

    glColor3f(0.00f, 0.40f, 0.20f);

    glBegin(GL_POLYGON);

    glVertex2f(0.001562f, 0.216667f);
    glVertex2f(0.109375f, 0.200000f + wave);
    glVertex2f(0.104688f, 0.100000f + wave * 0.45f);
    glVertex2f(0.001562f, 0.116667f);

    glEnd();

    glColor3f(0.91f, 0.08f, 0.14f);

    circle(
        0.051562f,
        0.158333f + wave * 0.28f,
        0.030556f
    );
}

void drawBuilding()
{
    drawRearCentralBuilding();
    drawLeftWing();
    drawRightWing();
    drawCentralFacade();
    drawSideConcreteDetails();
    drawFacadeOpenings();
    drawTopDetails();
    drawParliamentPlaza();
    drawFlag();
}

void drawLawn()
{
    glColor3f(0.34f, 0.68f, 0.14f);

    rect(-1.0f, -0.847222f, 1.0f, -0.583333f);

    for (int i = 0; i < 12; i++)
    {
        float y = -0.838889f + i * 0.022222f;

        glColor4f(
            0.16f,
            0.42f + i * 0.008f,
            0.07f,
            0.12f
        );

        rect(-1.0f, y, 1.0f, y + 0.011111f);
    }

    glColor3f(0.49f, 0.47f, 0.40f);

    rect(-1.0f, -0.594444f, 1.0f, -0.577778f);
}

void drawWalkway()
{
    glColor3f(0.78f, 0.77f, 0.73f);

    glBegin(GL_POLYGON);

    glVertex2f(-0.164062f, -0.583333f);
    glVertex2f(0.164062f, -0.583333f);
    glVertex2f(0.382812f, -0.847222f);
    glVertex2f(-0.382812f, -0.847222f);

    glEnd();

    glColor4f(1.0f, 1.0f, 1.0f, 0.25f);

    glBegin(GL_LINES);

    for (int i = 1; i < 6; i++)
    {
        float y = -0.583333f - i * 0.047222f;
        float halfWidth = 0.164062f + i * 0.054688f;

        glVertex2f(-halfWidth, y);
        glVertex2f(halfWidth, y);
    }

    glEnd();

    glColor4f(0.35f, 0.34f, 0.31f, 0.22f);

    glBegin(GL_LINES);

    glVertex2f(-0.164062f, -0.583333f);
    glVertex2f(-0.382812f, -0.847222f);

    glVertex2f(0.164062f, -0.583333f);
    glVertex2f(0.382812f, -0.847222f);

    glEnd();
}

void drawTree(float x, float y, float scale)
{
    glPushMatrix();

    glTranslatef(x, y, 0.0f);
    glScalef(scale, scale, 1.0f);

    glColor4f(0.04f, 0.12f, 0.04f, 0.17f);

    ellipse(0.0f, 0.0f, 0.056250f, 0.022222f);

    glColor3f(0.28f, 0.18f, 0.08f);

    rect(-0.007812f, 0.0f, 0.007812f, 0.116667f);

    glColor3f(0.06f, 0.30f, 0.08f);

    circle(-0.031250f, 0.119444f, 0.063889f);
    circle(0.0f, 0.152778f, 0.080556f);
    circle(0.037500f, 0.122222f, 0.063889f);
    circle(0.0f, 0.105556f, 0.072222f);

    glColor3f(0.10f, 0.43f, 0.10f);

    circle(-0.021875f, 0.152778f, 0.050000f);
    circle(0.020313f, 0.158333f, 0.050000f);
    circle(0.003125f, 0.186111f, 0.041667f);

    glColor4f(0.32f, 0.62f, 0.18f, 0.42f);

    circle(-0.015625f, 0.180556f, 0.019444f);
    circle(0.025000f, 0.152778f, 0.019444f);
    circle(-0.040625f, 0.127778f, 0.016667f);

    glPopMatrix();
}

void drawTrees()
{
    drawTree(-0.859375f, -0.777778f, 0.78f);
    drawTree(-0.648438f, -0.783333f, 0.72f);
    drawTree(-0.445312f, -0.780556f, 0.66f);

    drawTree(0.445312f, -0.780556f, 0.67f);
    drawTree(0.648438f, -0.783333f, 0.72f);
    drawTree(0.859375f, -0.777778f, 0.78f);
}

void drawBush(float x, float y, float scale)
{
    glPushMatrix();

    glTranslatef(x, y, 0.0f);
    glScalef(scale, scale, 1.0f);

    glColor3f(0.05f, 0.29f, 0.07f);

    circle(-0.031250f, 0.027778f, 0.050000f);
    circle(0.0f, 0.050000f, 0.063889f);
    circle(0.034375f, 0.027778f, 0.050000f);
    circle(0.004687f, 0.013889f, 0.061111f);

    glColor3f(0.10f, 0.42f, 0.10f);

    circle(-0.015625f, 0.055556f, 0.033333f);
    circle(0.018750f, 0.061111f, 0.036111f);

    glPopMatrix();
}

void drawForeground()
{
    drawBush(-0.882812f, -0.841667f, 0.85f);
    drawBush(-0.531250f, -0.841667f, 0.70f);
    drawBush(0.531250f, -0.841667f, 0.72f);
    drawBush(0.890625f, -0.841667f, 0.88f);
}

void drawRoad()
{
    glColor3f(0.30f, 0.32f, 0.36f);

    rect(-1.0f, -1.0f, 1.0f, -0.847222f);

    glColor3f(0.74f, 0.74f, 0.72f);

    rect(-1.0f, -0.858333f, 1.0f, -0.847222f);

    glColor3f(0.93f, 0.91f, 0.76f);

    for (float x = -0.968750f; x < 1.0f; x += 0.234375f)
    {
        rect(x, -0.930556f, x + 0.117188f, -0.922222f);
    }

    glColor4f(0.06f, 0.06f, 0.07f, 0.18f);

    rect(-1.0f, -1.0f, 1.0f, -0.986111f);
}

void drawWheel(float x, float y, float radius)
{
    glColor3f(0.045f, 0.045f, 0.05f);

    circle(x, y, radius);

    glColor3f(0.35f, 0.36f, 0.38f);

    circle(x, y, radius * 0.55f);

    glColor3f(0.72f, 0.73f, 0.75f);

    circle(x, y, radius * 0.28f);

    glPushMatrix();

    glTranslatef(x, y, 0.0f);
    glRotatef(wheelAngle, 0.0f, 0.0f, 1.0f);

    glColor3f(0.18f, 0.19f, 0.20f);

    glLineWidth(1.5f);

    glBegin(GL_LINES);

    for (int i = 0; i < 6; i++)
    {
        float angle = 2.0f * PI * i / 6.0f;

        glVertex2f(0.0f, 0.0f);

        glVertex2f(
            cos(angle) * radius * 0.48f * 0.5625f,
            sin(angle) * radius * 0.48f
        );
    }

    glEnd();

    glLineWidth(1.0f);

    glPopMatrix();
}

void drawCar()
{
    if (!carVisible)
        return;

    float x = -1.0f + carMove;
    float y = -0.980556f;

    glColor4f(0.02f, 0.02f, 0.02f, 0.18f);

    ellipse(
        x + 0.128125f,
        y + 0.008333f,
        0.121875f,
        0.016667f
    );

    glColor3f(0.10f, 0.30f, 0.55f);

    glBegin(GL_POLYGON);

    glVertex2f(x + 0.009375f, y + 0.047222f);
    glVertex2f(x + 0.023438f, y + 0.083333f);
    glVertex2f(x + 0.065625f, y + 0.097222f);
    glVertex2f(x + 0.087500f, y + 0.133333f);
    glVertex2f(x + 0.162500f, y + 0.133333f);
    glVertex2f(x + 0.189062f, y + 0.100000f);
    glVertex2f(x + 0.229687f, y + 0.088889f);
    glVertex2f(x + 0.246875f, y + 0.063889f);
    glVertex2f(x + 0.239063f, y + 0.041667f);
    glVertex2f(x + 0.012500f, y + 0.041667f);

    glEnd();

    glColor3f(0.07f, 0.23f, 0.45f);

    glBegin(GL_POLYGON);

    glVertex2f(x + 0.062500f, y + 0.097222f);
    glVertex2f(x + 0.090625f, y + 0.141667f);
    glVertex2f(x + 0.164062f, y + 0.141667f);
    glVertex2f(x + 0.190625f, y + 0.100000f);

    glEnd();

    glColor3f(0.63f, 0.82f, 0.91f);

    glBegin(GL_POLYGON);

    glVertex2f(x + 0.075000f, y + 0.100000f);
    glVertex2f(x + 0.095312f, y + 0.133333f);
    glVertex2f(x + 0.121875f, y + 0.133333f);
    glVertex2f(x + 0.121875f, y + 0.100000f);

    glEnd();

    glBegin(GL_POLYGON);

    glVertex2f(x + 0.128125f, y + 0.100000f);
    glVertex2f(x + 0.128125f, y + 0.133333f);
    glVertex2f(x + 0.159375f, y + 0.133333f);
    glVertex2f(x + 0.181250f, y + 0.100000f);

    glEnd();

    glColor4f(1.0f, 1.0f, 1.0f, 0.30f);

    glBegin(GL_POLYGON);

    glVertex2f(x + 0.079687f, y + 0.105556f);
    glVertex2f(x + 0.096875f, y + 0.130556f);
    glVertex2f(x + 0.104688f, y + 0.130556f);
    glVertex2f(x + 0.089063f, y + 0.105556f);

    glEnd();

    glColor3f(0.055f, 0.19f, 0.37f);

    rect(
        x + 0.123438f,
        y + 0.052778f,
        x + 0.128125f,
        y + 0.097222f
    );

    rect(
        x + 0.189062f,
        y + 0.055556f,
        x + 0.192188f,
        y + 0.094444f
    );

    glColor3f(0.05f, 0.05f, 0.06f);

    rect(
        x + 0.145313f,
        y + 0.086111f,
        x + 0.159375f,
        y + 0.091667f
    );

    glColor3f(0.90f, 0.91f, 0.93f);

    rect(
        x + 0.235937f,
        y + 0.066667f,
        x + 0.246875f,
        y + 0.080556f
    );

    glColor3f(0.95f, 0.22f, 0.12f);

    rect(
        x + 0.012500f,
        y + 0.063889f,
        x + 0.021875f,
        y + 0.080556f
    );

    glColor3f(0.08f, 0.08f, 0.09f);

    rect(
        x + 0.242188f,
        y + 0.044444f,
        x + 0.253125f,
        y + 0.055556f
    );

    rect(
        x + 0.001563f,
        y + 0.044444f,
        x + 0.014063f,
        y + 0.055556f
    );

    glColor3f(0.06f, 0.16f, 0.28f);

    glLineWidth(1.5f);

    glBegin(GL_LINES);

    glVertex2f(x + 0.126562f, y + 0.050000f);
    glVertex2f(x + 0.126562f, y + 0.097222f);

    glVertex2f(x + 0.190625f, y + 0.050000f);
    glVertex2f(x + 0.190625f, y + 0.097222f);

    glVertex2f(x + 0.028125f, y + 0.050000f);
    glVertex2f(x + 0.223438f, y + 0.050000f);

    glEnd();

    glLineWidth(1.0f);

    drawWheel(
        x + 0.060937f,
        y + 0.041667f,
        0.030556f
    );

    drawWheel(
        x + 0.196875f,
        y + 0.041667f,
        0.030556f
    );
}

void drawTopLeftLeaves()
{
    glColor3f(0.15f, 0.24f, 0.07f);

    glLineWidth(6.0f);

    glBegin(GL_LINES);

    glVertex2f(-1.0f, 0.958333f);
    glVertex2f(-0.773438f, 0.791667f);

    glVertex2f(-0.960938f, 1.0f);
    glVertex2f(-0.859375f, 0.736111f);

    glEnd();

    glLineWidth(1.0f);

    glColor3f(0.07f, 0.32f, 0.07f);

    ellipse(-0.953125f, 0.916667f, 0.037500f, 0.036111f);
    ellipse(-0.898438f, 0.894444f, 0.039062f, 0.038889f);
    ellipse(-0.851562f, 0.847222f, 0.037500f, 0.036111f);
    ellipse(-0.804688f, 0.797222f, 0.035937f, 0.033333f);
    ellipse(-0.945312f, 0.811111f, 0.037500f, 0.036111f);
    ellipse(-0.887500f, 0.763889f, 0.035937f, 0.036111f);

    glColor3f(0.21f, 0.49f, 0.09f);

    ellipse(-0.925000f, 0.952778f, 0.028125f, 0.027778f);
    ellipse(-0.871875f, 0.905556f, 0.029687f, 0.027778f);
    ellipse(-0.820312f, 0.861111f, 0.028125f, 0.027778f);
    ellipse(-0.925000f, 0.761111f, 0.026562f, 0.027778f);
}

void drawScene()
{
    drawSky();
    drawSun();
    drawClouds();
    drawBirds();

    drawDistantGreenery();
    drawLake();

    drawBuilding();

    drawLawn();
    drawWalkway();

    drawTrees();
    drawForeground();

    drawRoad();
    drawCar();

    drawTopLeftLeaves();
}

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    drawScene();

    glFlush();
}

void timer(int value)
{
    birdMove += 0.0021875f;
    birdWing += 0.18f;

    if (birdMove > 1.30f)
    {
        birdMove = -0.30f;
    }

    if (carMoving)
    {
        carMove += 0.003125f;
        wheelAngle -= 8.0f;

        if (wheelAngle < -360.0f)
        {
            wheelAngle += 360.0f;
        }

        if (carMove >= 1.746875f)
        {
            carMove = 1.746875f;
            carMoving = false;
            carVisible = false;
        }
    }

    flagWave += 0.10f;

    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}

void keyboard(unsigned char key, int x, int y)
{
    if (key == 27)
    {
        exit(0);
    }

    if (key == 14)
    {
        carMove = 0.0f;
        wheelAngle = 0.0f;
        carVisible = true;
        carMoving = true;
    }
}

void init()
{
    glClearColor(0.68f, 0.86f, 0.97f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST);
}

}

#undef PI

#pragma pop_macro("PI")



#pragma push_macro("PI")
#undef PI

namespace ShatGombuj {

#define PI 3.14159265358979323846


// SHAT GOMBUJ MOSQUE


int viewMode = 1;

// Animation
float timeOfDay = 0.25f;
bool isAnimating = true;

float skyR = 0.48f, skyG = 0.72f, skyB = 0.88f;
float ambientLight = 1.0f;


const int STAR_COUNT = 35;
float starX[STAR_COUNT];
float starY[STAR_COUNT];
float starSize[STAR_COUNT];

// WALKING PEOPLE

struct Person {
    float x;
    float y;
    float speed;
    int direction;
    float scale;
    float colorR, colorG, colorB;
    float pantR, pantG, pantB;
    float legAngle;
    float legSpeed;
};

const int PERSON_COUNT = 4;
Person people[PERSON_COUNT];

void initPeople() {
    people[0] = { -75.0f, -6.5f, 0.15f,  1, 1.8f, 0.8f, 0.2f, 0.2f, 0.15f, 0.15f, 0.35f, 0.0f, 0.1f };
    people[1] = {  60.0f, -7.2f, 0.12f, -1, 1.7f, 0.2f, 0.5f, 0.8f, 0.20f, 0.20f, 0.20f, 0.0f, 0.09f };
    people[2] = { -40.0f, -5.8f, 0.10f,  1, 1.6f, 0.9f, 0.9f, 0.9f, 0.10f, 0.25f, 0.15f, 0.0f, 0.08f };
    people[3] = {  20.0f, -6.8f, 0.14f, -1, 1.9f, 0.1f, 0.7f, 0.3f, 0.15f, 0.15f, 0.15f, 0.0f, 0.1f };
}

void initStars() {
    for (int i = 0; i < STAR_COUNT; i++) {
        starX[i] = -85.0f + (float)(rand() % 170);
        starY[i] = 12.0f + (float)(rand() % 26);
        starSize[i] = 0.4f + (float)(rand() % 100) / 200.0f;
    }
}


float lerp(float a, float b, float t) {
    return a + t * (b - a);
}

// COLORS


void brick() {
    glColor3f(0.52f * ambientLight, 0.24f * ambientLight, 0.10f * ambientLight);
}

void brickLight() {
    glColor3f(0.65f * ambientLight, 0.31f * ambientLight, 0.14f * ambientLight);
}

void brickDark() {
    glColor3f(0.35f * ambientLight, 0.13f * ambientLight, 0.045f * ambientLight);
}

void darkDoor() {
    glColor3f(0.045f * ambientLight, 0.025f * ambientLight, 0.015f * ambientLight);
}

void grass() {
    glColor3f(0.12f * ambientLight, 0.38f * ambientLight, 0.08f * ambientLight);
}

void pathColor() {
    glColor3f(0.58f * ambientLight, 0.36f * ambientLight, 0.20f * ambientLight);
}

// RECTANGLE & BASIC SHAPES


void rectangle(float x1, float y1, float x2, float y2) {
    glBegin(GL_QUADS);
    glVertex2f(x1, y1);
    glVertex2f(x2, y1);
    glVertex2f(x2, y2);
    glVertex2f(x1, y2);
    glEnd();
}

void drawCircle(float cx, float cy, float r, int num_segments) {
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= num_segments; i++) {
        float theta = 2.0f * PI * float(i) / float(num_segments);
        float x = r * cosf(theta);
        float y = r * sinf(theta);
        glVertex2f(cx + x, cy + y);
    }
    glEnd();
}

void draw5PointStar(float cx, float cy, float radius, float alpha) {
    glColor4f(1.0f, 1.0f, 0.85f, alpha);
    float innerRadius = radius * 0.4f;

    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(cx, cy);
    for (int i = 0; i <= 10; i++) {
        float angle = i * PI / 5.0f - (PI / 2.0f);
        float r = (i % 2 == 0) ? radius : innerRadius;
        float x = cx + r * cosf(angle);
        float y = cy + r * sinf(angle);
        glVertex2f(x, y);
    }
    glEnd();
}

// STAIRS


void drawMosqueEntranceStairs() {
    glColor3f(0.35f * ambientLight, 0.16f * ambientLight, 0.06f * ambientLight);
    rectangle(-7.0f, 2.0f, 7.0f, 3.0f);

    glColor3f(0.40f * ambientLight, 0.19f * ambientLight, 0.08f * ambientLight);
    rectangle(-6.0f, 3.0f, 6.0f, 4.0f);

    glColor3f(0.45f * ambientLight, 0.22f * ambientLight, 0.10f * ambientLight);
    rectangle(-5.0f, 4.0f, 5.0f, 5.0f);
}

void drawDome(float cx, float baseY, float radius, float height) {
    brickDark();
    rectangle(cx - radius - 0.3f, baseY - 0.6f, cx + radius + 0.3f, baseY);

    glColor3f(0.45f * ambientLight, 0.20f * ambientLight, 0.08f * ambientLight);
    rectangle(cx - radius - 0.1f, baseY - 0.2f, cx + radius + 0.1f, baseY + 0.3f);

    int segments = 40;
    glBegin(GL_TRIANGLE_STRIP);
    for (int i = 0; i <= segments; i++) {
        float angle = PI - (PI * i / segments);
        float normX = cosf(angle);
        float normY = sinf(angle);

        float x = cx + radius * normX;
        float y = baseY + 0.3f + height * normY;

        float shadowFactor = 0.55f + 0.45f * normX + 0.3f * normY;
        if (shadowFactor > 1.0f) shadowFactor = 1.0f;
        if (shadowFactor < 0.35f) shadowFactor = 0.35f;

        glColor3f(0.68f * ambientLight * shadowFactor,
                  0.34f * ambientLight * shadowFactor,
                  0.15f * ambientLight * shadowFactor);

        glVertex2f(x, y);
        glVertex2f(cx, baseY + 0.3f);
    }
    glEnd();

    glLineWidth(1.5f);
    glColor4f(0.25f * ambientLight, 0.08f * ambientLight, 0.02f * ambientLight, 0.45f);
    int numRibs = 7;
    for (int i = 1; i < numRibs; i++) {
        float angle = PI - (PI * i / numRibs);
        float rx = cx + radius * cosf(angle);
        float ry = baseY + 0.3f + height * sinf(angle);

        glBegin(GL_LINE_STRIP);
        glVertex2f(cx, baseY + 0.3f + height);
        glVertex2f(rx, ry);
        glEnd();
    }

    float apexY = baseY + 0.3f + height;
    glColor3f(0.35f * ambientLight, 0.15f * ambientLight, 0.05f * ambientLight);
    rectangle(cx - 0.25f, apexY, cx + 0.25f, apexY + 0.4f);

    glColor3f(0.75f * ambientLight, 0.55f * ambientLight, 0.15f * ambientLight);
    drawCircle(cx, apexY + 0.6f, 0.3f, 12);

    glColor3f(0.85f * ambientLight, 0.65f * ambientLight, 0.20f * ambientLight);
    drawCircle(cx, apexY + 1.0f, 0.2f, 10);

    glLineWidth(2.0f);
    glBegin(GL_LINES);
    glVertex2f(cx, apexY + 1.0f);
    glVertex2f(cx, apexY + 1.7f);
    glEnd();
}

// WALKING PERSON

void drawPerson(Person p) {
    float personAlpha = (ambientLight - 0.35f) / 0.65f;
    if (personAlpha < 0.0f) personAlpha = 0.0f;
    if (personAlpha > 1.0f) personAlpha = 1.0f;

    if (personAlpha <= 0.01f) return;

    glPushMatrix();
    glTranslatef(p.x, p.y, 0.0f);
    glScalef(p.scale * p.direction, p.scale, 1.0f);

    float legSwing = sin(p.legAngle);
    float armSwing = cos(p.legAngle);

    //  Face
    glColor4f(0.88f * ambientLight, 0.68f * ambientLight, 0.50f * ambientLight, personAlpha);
    drawCircle(0.0f, 3.2f, 0.42f, 16);

    //  Hair
    glColor4f(0.12f * ambientLight, 0.08f * ambientLight, 0.05f * ambientLight, personAlpha);
    drawCircle(0.0f, 3.48f, 0.28f, 12); // Top Hair Arc
    drawCircle(-0.15f, 3.42f, 0.22f, 10);
    drawCircle(0.15f, 3.42f, 0.22f, 10);

    // Neck
    glColor4f(0.80f * ambientLight, 0.60f * ambientLight, 0.45f * ambientLight, personAlpha);
    rectangle(-0.1f, 2.7f, 0.1f, 2.85f);

    //  (Shirt)
    glColor4f(p.colorR * ambientLight, p.colorG * ambientLight, p.colorB * ambientLight, personAlpha);
    glBegin(GL_POLYGON);
    glVertex2f(-0.55f, 2.7f);
    glVertex2f( 0.55f, 2.7f);
    glVertex2f( 0.42f, 1.4f);
    glVertex2f(-0.42f, 1.4f);
    glEnd();

    // Shirt Collar
    glColor4f(p.colorR * 0.7f * ambientLight, p.colorG * 0.7f * ambientLight, p.colorB * 0.7f * ambientLight, personAlpha);
    glLineWidth(1.5f);
    glBegin(GL_LINES);
    glVertex2f(-0.2f, 2.7f);
    glVertex2f(0.0f, 2.45f);
    glVertex2f(0.2f, 2.7f);
    glEnd();

    // Legs
    glColor4f(p.pantR * ambientLight, p.pantG * ambientLight, p.pantB * ambientLight, personAlpha);
    glLineWidth(4.0f);

    // Back Leg
    float backKneeX = -0.15f + legSwing * 0.4f;
    float backKneeY = 0.8f;
    float backFootX = backKneeX + legSwing * 0.3f;
    float backFootY = 0.0f;

    glBegin(GL_LINES);
    glVertex2f(-0.18f, 1.4f);
    glVertex2f(backKneeX, backKneeY);
    glVertex2f(backKneeX, backKneeY);
    glVertex2f(backFootX, backFootY);
    glEnd();

    // Front Leg
    float frontKneeX = 0.15f - legSwing * 0.4f;
    float frontKneeY = 0.8f;
    float frontFootX = frontKneeX - legSwing * 0.3f;
    float frontFootY = 0.0f;

    glBegin(GL_LINES);
    glVertex2f(0.18f, 1.4f);
    glVertex2f(frontKneeX, frontKneeY);
    glVertex2f(frontKneeX, frontKneeY);
    glVertex2f(frontFootX, frontFootY);
    glEnd();

    // Shoes
    glColor4f(0.05f * ambientLight, 0.05f * ambientLight, 0.05f * ambientLight, personAlpha);
    rectangle(backFootX - 0.1f, backFootY, backFootX + 0.25f, backFootY + 0.18f);
    rectangle(frontFootX - 0.1f, frontFootY, frontFootX + 0.25f, frontFootY + 0.18f);

    //  Arms with Elbow
    glColor4f(p.colorR * 0.85f * ambientLight, p.colorG * 0.85f * ambientLight, p.colorB * 0.85f * ambientLight, personAlpha);
    glLineWidth(3.0f);

    // Left Arm
    float lElbowX = -0.45f - armSwing * 0.3f;
    float lElbowY = 2.0f;
    float lHandX  = lElbowX - armSwing * 0.25f;
    float lHandY  = 1.4f;

    glBegin(GL_LINES);
    glVertex2f(-0.45f, 2.65f);
    glVertex2f(lElbowX, lElbowY);
    glVertex2f(lElbowX, lElbowY);
    glVertex2f(lHandX, lHandY);
    glEnd();

    // Right Arm
    float rElbowX = 0.45f + armSwing * 0.3f;
    float rElbowY = 2.0f;
    float rHandX  = rElbowX + armSwing * 0.25f;
    float rHandY  = 1.4f;

    glBegin(GL_LINES);
    glVertex2f(0.45f, 2.65f);
    glVertex2f(rElbowX, rElbowY);
    glVertex2f(rElbowX, rElbowY);
    glVertex2f(rHandX, rHandY);
    glEnd();

    // Hands
    glColor4f(0.88f * ambientLight, 0.68f * ambientLight, 0.50f * ambientLight, personAlpha);
    drawCircle(lHandX, lHandY, 0.1f, 8);
    drawCircle(rHandX, rHandY, 0.1f, 8);

    glPopMatrix();
}

// BENCH IN FIELD CORNER WITH SEATED PEOPLE

void drawBenchWithPeople(float x, float y) {
    // Bench
    glColor3f(0.1f * ambientLight, 0.1f * ambientLight, 0.12f * ambientLight);
    rectangle(x - 3.8f, y, x - 3.4f, y + 1.8f);
    rectangle(x + 3.4f, y, x + 3.8f, y + 1.8f);
    rectangle(x - 0.2f, y, x + 0.2f, y + 1.8f);

    glColor3f(0.42f * ambientLight, 0.20f * ambientLight, 0.08f * ambientLight);
    rectangle(x - 4.2f, y + 1.8f, x + 4.2f, y + 2.2f);
    rectangle(x - 4.2f, y + 2.3f, x + 4.2f, y + 2.7f);

    glColor3f(0.38f * ambientLight, 0.18f * ambientLight, 0.06f * ambientLight);
    rectangle(x - 4.2f, y + 3.4f, x + 4.2f, y + 3.8f);
    rectangle(x - 4.2f, y + 4.0f, x + 4.2f, y + 4.4f);

    glColor3f(0.1f * ambientLight, 0.1f * ambientLight, 0.12f * ambientLight);
    rectangle(x - 3.8f, y + 2.7f, x - 3.4f, y + 4.5f);
    rectangle(x + 3.4f, y + 2.7f, x + 3.8f, y + 4.5f);

    // Seated People
    if (timeOfDay < 0.74f) {
        // Person 1
        glColor3f(0.88f * ambientLight, 0.68f * ambientLight, 0.50f * ambientLight); // Skin Face
        drawCircle(x - 2.0f, y + 5.1f, 0.55f, 15);
        glColor3f(0.15f * ambientLight, 0.10f * ambientLight, 0.05f * ambientLight); // Hair Top
        drawCircle(x - 2.0f, y + 5.45f, 0.35f, 12);

        glColor3f(0.8f * ambientLight, 0.2f * ambientLight, 0.2f * ambientLight); // Shirt
        rectangle(x - 2.6f, y + 2.4f, x - 1.4f, y + 4.5f);

        glColor3f(0.15f * ambientLight, 0.15f * ambientLight, 0.35f * ambientLight); // Pants
        rectangle(x - 2.5f, y + 1.8f, x - 1.5f, y + 2.4f);
        rectangle(x - 2.4f, y + 0.4f, x - 2.0f, y + 1.8f);
        rectangle(x - 1.9f, y + 0.4f, x - 1.5f, y + 1.8f);

        // Person 2
        glColor3f(0.88f * ambientLight, 0.68f * ambientLight, 0.50f * ambientLight); // Skin Face
        drawCircle(x + 2.0f, y + 5.1f, 0.55f, 15);
        glColor3f(0.15f * ambientLight, 0.10f * ambientLight, 0.05f * ambientLight); // Hair Top
        drawCircle(x + 2.0f, y + 5.45f, 0.35f, 12);

        glColor3f(0.2f * ambientLight, 0.4f * ambientLight, 0.8f * ambientLight); // Shirt
        rectangle(x + 1.4f, y + 2.4f, x + 2.6f, y + 4.5f);

        glColor3f(0.15f * ambientLight, 0.25f * ambientLight, 0.15f * ambientLight); // Pants
        rectangle(x + 1.5f, y + 1.8f, x + 2.5f, y + 2.4f);
        rectangle(x + 1.5f, y + 0.4f, x + 1.9f, y + 1.8f);
        rectangle(x + 2.0f, y + 0.4f, x + 2.4f, y + 1.8f);
    }
}

// LAMPPOST

void drawLampPost(float x, float y) {
    glColor3f(0.12f * ambientLight, 0.12f * ambientLight, 0.15f * ambientLight);
    rectangle(x - 0.25f, y, x + 0.25f, y + 6.2f);

    rectangle(x - 0.6f, y, x + 0.6f, y + 0.5f);
    rectangle(x - 0.45f, y + 0.5f, x + 0.45f, y + 0.8f);
    rectangle(x - 0.4f, y + 5.7f, x + 0.4f, y + 5.9f);

    glColor3f(0.18f * ambientLight, 0.18f * ambientLight, 0.20f * ambientLight);
    glBegin(GL_POLYGON);
    glVertex2f(x - 0.6f, y + 5.9f);
    glVertex2f(x + 0.6f, y + 5.9f);
    glVertex2f(x + 0.8f, y + 7.0f);
    glVertex2f(x - 0.8f, y + 7.0f);
    glEnd();

    glColor3f(0.08f * ambientLight, 0.08f * ambientLight, 0.10f * ambientLight);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - 0.9f, y + 7.0f);
    glVertex2f(x + 0.9f, y + 7.0f);
    glVertex2f(x, y + 7.7f);
    glEnd();

    float lightGlow = (0.75f - ambientLight) / 0.5f;
    if (lightGlow < 0.0f) lightGlow = 0.0f;
    if (lightGlow > 1.0f) lightGlow = 1.0f;

    if (lightGlow > 0.02f) {
        glBegin(GL_TRIANGLES);
        glColor4f(1.0f, 0.88f, 0.4f, lightGlow * 0.40f);
        glVertex2f(x, y + 6.4f);
        glColor4f(1.0f, 0.75f, 0.2f, 0.0f);
        glVertex2f(x - 4.5f, y - 0.5f);
        glVertex2f(x + 4.5f, y - 0.5f);
        glEnd();
    }

    if (lightGlow > 0.02f) {
        glColor4f(1.0f, 0.80f, 0.3f, lightGlow * 0.15f);
        drawCircle(x, y + 6.4f, 4.5f, 30);

        glColor4f(1.0f, 0.88f, 0.4f, lightGlow * 0.30f);
        drawCircle(x, y + 6.4f, 2.5f, 25);

        glColor4f(1.0f, 0.95f, 0.6f, lightGlow * 0.55f);
        drawCircle(x, y + 6.4f, 1.2f, 20);
    }

    glColor3f(lerp(0.7f * ambientLight, 1.0f, lightGlow),
              lerp(0.65f * ambientLight, 0.98f, lightGlow),
              lerp(0.4f * ambientLight, 0.75f, lightGlow));
    drawCircle(x, y + 6.4f, 0.55f, 15);
}

// FLOWER & TREE DRAWING

void drawBigFlower(float x, float y, float size) {
    glColor3f(0.05f * ambientLight, 0.35f * ambientLight, 0.05f * ambientLight);
    glLineWidth(2.5f);
    glBegin(GL_LINES);
    glVertex2f(x, y - size * 1.5f);
    glVertex2f(x, y);
    glEnd();

    glColor3f(0.95f * ambientLight, 0.8f * ambientLight, 0.1f * ambientLight);
    int numPetals = 6;
    for (int i = 0; i < numPetals; i++) {
        float angle = i * (2.0f * PI / numPetals);
        float px = x + cosf(angle) * (size * 0.7f);
        float py = y + sinf(angle) * (size * 0.7f);
        drawCircle(px, py, size * 0.45f, 10);
    }

    glColor3f(0.85f * ambientLight, 0.35f * ambientLight, 0.05f * ambientLight);
    drawCircle(x, y, size * 0.4f, 12);
}

void drawMediumTree(float x, float y, float scale) {
    glColor3f(0.35f * ambientLight, 0.18f * ambientLight, 0.08f * ambientLight);
    rectangle(x - 0.5f * scale, y, x + 0.5f * scale, y + 3.8f * scale);

    glColor3f(0.08f * ambientLight, 0.32f * ambientLight, 0.06f * ambientLight);
    drawCircle(x - 1.1f * scale, y + 3.5f * scale, 1.5f * scale, 15);
    drawCircle(x + 1.1f * scale, y + 3.5f * scale, 1.5f * scale, 15);

    glColor3f(0.12f * ambientLight, 0.42f * ambientLight, 0.08f * ambientLight);
    drawCircle(x, y + 4.8f * scale, 1.8f * scale, 15);
    drawCircle(x - 0.8f * scale, y + 5.3f * scale, 1.4f * scale, 15);
    drawCircle(x + 0.8f * scale, y + 5.3f * scale, 1.4f * scale, 15);

    glColor3f(0.18f * ambientLight, 0.50f * ambientLight, 0.12f * ambientLight);
    drawCircle(x, y + 6.2f * scale, 1.5f * scale, 15);
}

// SUN, MOON & STARS

void drawSunAndMoon() {
    float angle = timeOfDay * 2.0f * PI - (PI / 2.0f);
    float celestialX = 60.0f * cos(angle);
    float celestialY = -5.0f + 40.0f * sin(angle);

    if (timeOfDay >= 0.0f && timeOfDay <= 0.5f) {
        glColor3f(1.0f, 0.85f, 0.2f);
        drawCircle(celestialX, celestialY, 3.5f, 30);
    } else {
        if (ambientLight < 0.6f) {
            float starAlpha = (0.6f - ambientLight) / 0.4f;
            for (int i = 0; i < STAR_COUNT; i++) {
                draw5PointStar(starX[i], starY[i], starSize[i], starAlpha);
            }
        }

        glColor3f(0.9f, 0.9f, 0.85f);
        drawCircle(-celestialX, -celestialY + 10.0f, 3.0f, 30);
    }
}

// ARCH

void drawArch(float cx, float bottom, float width, float height) {
    float half = width / 2.0f;
    glBegin(GL_POLYGON);
    glVertex2f(cx - half, bottom);
    glVertex2f(cx - half, bottom + height * 0.48f);
    glVertex2f(cx - half * 0.75f, bottom + height * 0.75f);
    glVertex2f(cx - half * 0.42f, bottom + height * 0.92f);
    glVertex2f(cx, bottom + height);
    glVertex2f(cx + half * 0.42f, bottom + height * 0.92f);
    glVertex2f(cx + half * 0.75f, bottom + height * 0.75f);
    glVertex2f(cx + half, bottom + height * 0.48f);
    glVertex2f(cx + half, bottom);
    glEnd();
}

void drawArchBorder(float cx, float bottom, float width, float height) {
    brickLight();
    glLineWidth(3.0f);
    glBegin(GL_LINE_STRIP);
    float half = width / 2.0f;
    glVertex2f(cx - half, bottom);
    glVertex2f(cx - half, bottom + height * 0.48f);
    glVertex2f(cx - half * 0.75f, bottom + height * 0.75f);
    glVertex2f(cx - half * 0.42f, bottom + height * 0.92f);
    glVertex2f(cx, bottom + height);
    glVertex2f(cx + half * 0.42f, bottom + height * 0.92f);
    glVertex2f(cx + half * 0.75f, bottom + height * 0.75f);
    glVertex2f(cx + half, bottom + height * 0.48f);
    glVertex2f(cx + half, bottom);
    glEnd();
}


// MOSQUE


void drawMainWall() {
    brick();
    rectangle(-44.0f, 5.0f, 44.0f, 20.0f);

    brickDark();
    rectangle(-44.0f, 5.0f, 44.0f, 5.6f);
    rectangle(-45.5f, 20.0f, 45.5f, 21.0f);

    brickLight();
    rectangle(-44.5f, 21.0f, 44.5f, 21.35f);
}

void drawFrontOpenings() {
    float startX = -36.0f;
    float gap = 7.2f;

    for (int i = 0; i < 11; i++) {
        float x = startX + i * gap;
        float width = 3.8f, height = 9.0f, bottom = 5.8f;

        if (i == 5) {
            width = 5.4f; height = 10.8f; bottom = 5.2f;
        }

        brickDark();
        drawArch(x, bottom, width + 0.7f, height + 0.7f);

        darkDoor();
        drawArch(x, bottom, width, height);

        drawArchBorder(x, bottom, width + 0.35f, height + 0.35f);
    }
}

void drawPillars() {
    float startX = -40.0f;
    float gap = 7.2f;
    brickLight();
    for (int i = 0; i <= 11; i++) {
        float x = startX + i * gap;
        rectangle(x - 0.45f, 5.0f, x + 0.45f, 20.0f);
    }
}

void drawTower(float cx) {
    brick();
    rectangle(cx - 4.2f, 4.0f, cx + 4.2f, 23.0f);

    brickDark();
    rectangle(cx - 4.4f, 7.0f, cx + 4.4f, 7.7f);
    rectangle(cx - 4.4f, 20.0f, cx + 4.4f, 20.7f);

    darkDoor();
    drawArch(cx, 15.0f, 2.5f, 5.0f);

    brickLight();
    drawArchBorder(cx, 15.0f, 2.8f, 5.3f);

    drawDome(cx, 22.8f, 4.4f, 4.2f);
}

void drawRoofDomes() {
    float startX = -36.0f;
    float gap = 7.2f;
    for (int i = 0; i < 11; i++) {
        float cx = startX + i * gap;
        drawDome(cx, 20.7f, 3.4f, 3.2f);
    }
}

void drawRoof() {
    brickDark();
    rectangle(-45.0f, 20.4f, 45.0f, 21.4f);
}

void drawGarden() {
    grass();
    rectangle(-80.0f, -8.0f, 80.0f, 5.0f);
    rectangle(-75.0f, 0.0f, -46.0f, 5.0f);
    rectangle(46.0f, 0.0f, 75.0f, 5.0f);
}

void drawWalkway() {
    pathColor();
    rectangle(-85.0f, -8.0f, 85.0f, -4.5f);

    glBegin(GL_QUADS);
    glVertex2f(-7.2f, 2.0f);
    glVertex2f(7.2f, 2.0f);
    glVertex2f(10.0f, -4.5f);
    glVertex2f(-10.0f, -4.5f);
    glEnd();
}

void drawGardenDecorations() {
    for (int i = 0; i < 4; i++) {
        float yPos = 2.0f - (i * 2.1f);
        drawMediumTree(-7.5f - (i * 0.8f), yPos, 0.85f);
        drawMediumTree(7.5f + (i * 0.8f), yPos, 0.85f);
    }

    for (int i = 0; i < 6; i++) {
        drawBigFlower(-20.0f - (i * 4.0f), 1.0f + (i % 2) * 1.5f, 1.0f);
        drawBigFlower(20.0f + (i * 4.0f), 1.0f + (i % 2) * 1.5f, 1.0f);
    }

    drawLampPost(-11.5f, -6.5f);
    drawLampPost(11.5f, -6.5f);
    drawBenchWithPeople(-65.0f, -8.0f);
}

void drawMosque() {
    grass();
    rectangle(-100.0f, -15.0f, 100.0f, 5.0f);

    drawMainWall();
    drawRoof();
    drawTower(-44.0f);
    drawTower(44.0f);
    drawFrontOpenings();
    drawPillars();
    drawRoofDomes();
    drawGarden();
    drawWalkway();

    drawMosqueEntranceStairs();
    drawGardenDecorations();

    for (int i = 0; i < PERSON_COUNT; i++) {
        drawPerson(people[i]);
    }
}

void updateEnvironment() {
    if (timeOfDay < 0.25f) {
        float t = timeOfDay / 0.25f;
        skyR = lerp(0.10f, 0.48f, t);
        skyG = lerp(0.12f, 0.72f, t);
        skyB = lerp(0.25f, 0.88f, t);
        ambientLight = lerp(0.35f, 1.00f, t);
    } else if (timeOfDay < 0.50f) {
        float t = (timeOfDay - 0.25f) / 0.25f;
        skyR = lerp(0.48f, 0.85f, t);
        skyG = lerp(0.72f, 0.45f, t);
        skyB = lerp(0.88f, 0.25f, t);
        ambientLight = lerp(1.00f, 0.65f, t);
    } else if (timeOfDay < 0.75f) {
        float t = (timeOfDay - 0.50f) / 0.25f;
        skyR = lerp(0.85f, 0.03f, t);
        skyG = lerp(0.45f, 0.05f, t);
        skyB = lerp(0.25f, 0.15f, t);
        ambientLight = lerp(0.65f, 0.25f, t);
    } else {
        float t = (timeOfDay - 0.75f) / 0.25f;
        skyR = lerp(0.03f, 0.10f, t);
        skyG = lerp(0.05f, 0.12f, t);
        skyB = lerp(0.15f, 0.25f, t);
        ambientLight = lerp(0.25f, 0.35f, t);
    }

    glClearColor(skyR, skyG, skyB, 1.0f);
}

void timer(int value) {
    if (isAnimating) {
        timeOfDay += 0.0015f;
        if (timeOfDay > 1.0f) {
            timeOfDay = 0.0f;
        }

        for (int i = 0; i < PERSON_COUNT; i++) {
            people[i].x += people[i].speed * people[i].direction;
            people[i].legAngle += people[i].legSpeed;

            if (people[i].direction == 1 && people[i].x > 88.0f) {
                people[i].x = -88.0f;
            } else if (people[i].direction == -1 && people[i].x < -88.0f) {
                people[i].x = 88.0f;
            }
        }
    }
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}


void display() {
    updateEnvironment();

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    drawSunAndMoon();
    drawMosque();

    glutSwapBuffers();
}

void reshape(int width, int height) {
    if (height == 0) height = 1;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    gluOrtho2D(-85.0, 85.0, -15.0, 40.0);
    glMatrixMode(GL_MODELVIEW);
}


void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        case ' ':
            isAnimating = !isAnimating;
            break;
        case 'd':
        case 'D':
            timeOfDay = 0.25f;
            break;
        case 'n':
        case 'N':
            timeOfDay = 0.75f;
            break;
        case 27:
            exit(0);
            break;
    }
    glutPostRedisplay();
}

void init() {
    initStars();
    initPeople();
    glDisable(GL_DEPTH_TEST);
    glShadeModel(GL_SMOOTH);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-85.0, 85.0, -15.0, 40.0);
    glMatrixMode(GL_MODELVIEW);
}

}

#undef PI
#pragma pop_macro("PI")

void display()
{
    int w = glutGet(GLUT_WINDOW_WIDTH);
    int h = glutGet(GLUT_WINDOW_HEIGHT);

    if (currentScene == 1)
    {
        // Scene 1 now uses the full window.
        glViewport(0, 0, w, h);

        // Restore the original Scene 1 projection logic.
        Sriti::display();

        glutSwapBuffers();
    }
    else if (currentScene == 2)
    {
        glViewport(0, 0, w, h);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        Shaheed::display();
    }
    else if (currentScene == 3)
    {
        glViewport(0, 0, w, h);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        Sangsad::display();

        glutSwapBuffers();
    }
    else
    {
        glViewport(0, 0, w, h);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(-85.0f, 85.0f, -15.0f, 40.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        ShatGombuj::display();
    }
}

void keyboard(unsigned char key, int x, int y)
{

    if (key == '1')
    {
        currentScene = 1;
        glutPostRedisplay();
        return;
    }

    if (key == '2')
    {
        currentScene = 2;
        glutPostRedisplay();
        return;
    }

    if (key == '3')
    {
        currentScene = 3;
        glutPostRedisplay();
        return;
    }

    if (key == '4')
    {
        currentScene = 4;
        glutPostRedisplay();
        return;
    }


    if (currentScene == 1)
    {
        Sriti::keyboard(key, x, y);
    }
    else if (currentScene == 2)
    {
        Shaheed::keyboard(key, x, y);
    }
    else if (currentScene == 3)
    {
        Sangsad::keyboard(key, x, y);
    }
    else
    {
        ShatGombuj::keyboard(key, x, y);
    }

    glutPostRedisplay();
}

void specialKeys(int key, int x, int y)
{
    if (currentScene == 1)
    {
        Sriti::specialKeys(key, x, y);
    }

    glutPostRedisplay();
}

void mouse(int button, int state, int x, int y)
{
    if (currentScene == 2)
    {
        Shaheed::mouse(button, state, x, y);
    }
}

void reshape(int w, int h)
{
    if (currentScene == 1)
    {

        glViewport(0, 0, w, h);


        Sriti::applyProjection();
    }
    else if (currentScene == 2)
    {
        glViewport(0, 0, w, h);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
    }
    else if (currentScene == 3)
    {
        glViewport(0, 0, w, h);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluOrtho2D(-1.0f, 1.0f, -1.0f, 1.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
    }
    else
    {
        ShatGombuj::reshape(w, h);
    }

    glutPostRedisplay();
}




int main(int argc, char** argv)
{
    glutInit(&argc, argv);

    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    glutInitWindowSize(1400, 800);
    glutInitWindowPosition(50, 50);

    glutCreateWindow("Historical places in BD");


    Sriti::init();
    Shaheed::init();
    Sangsad::init();
    ShatGombuj::init();


    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeys);
    glutMouseFunc(mouse);
    glutReshapeFunc(reshape);


    glutTimerFunc(20, Sriti::timer, 0);
    glutTimerFunc(30, Shaheed::update, 0);
    glutTimerFunc(16, Sangsad::timer, 0);
    glutTimerFunc(16, ShatGombuj::timer, 0);

    glutMainLoop();

    return 0;
}
